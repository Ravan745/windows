import {
  ClusterManager,
  HeartbeatManager,
  ReClusterManager,
  messageType,
} from "discord-hybrid-sharding";
import RaahiConfig from "./src/config/Config.js";
const Config = new RaahiConfig();
const manager = new ClusterManager("./build/src/raahi.js", {
  totalClusters: "auto",
  totalShards: "auto",
  respawn: true,
  token: Config.token,
  shardsPerClusters: 7,
  mode: "process",
  restarts: { max: 5, interval: 60000 * 60 },
  spawnOptions: {
    amount: "auto",
    delay: 10000,
    timeout: -1,
  },
});

manager.extend(
  new HeartbeatManager({
    interval: 2000,
    maxMissedHeartbeats: 5,
  })
);

manager.extend(new ReClusterManager());

manager.on("clusterReady", (cluster) =>
  console.log(`Cluster ready: ${cluster.id} ✨🌸`)
);
manager.on("clusterCreate", (cluster: any) => {
  cluster.on("message", (message: any) => {
    if (message?._type !== messageType.CUSTOM_REQUEST) return;
    message.reply({
      content: `Hello Raahi! ✨🌸`,
    });
  });
  console.log(`Cluster is Created: ${cluster.id} ✨🌸`);
});
manager.on("debug", (info) => console.info(info));
manager.spawn();

process.on("unhandledRejection", async (e: any) => {
  if (e && (e.code === 10062 || e.code === 40060 || e.code === 50035 || e.code === 10008)) return;
  console.error(`[Manager Unhandled Rejection]:`, e?.stack || e);
});
