import { Client, Partials, GatewayIntentBits } from "discord.js";
import RaahiConfig from "../config/Config.js";
import RaahiEmoji from "../config/Emoji.js";
import RaahiApi from "../api/Api.js";
import RaahiEvents from "./Events.js";
import RaahiCommands from "./Commands.js";
import { ClusterClient, getInfo } from "discord-hybrid-sharding";
import RaahiUtils from "./Utils.js";
import RaahiLogger from "./Logger.js";
import RaahiSpotify from "../api/Spotify.js";
import RaahiKazagumo from "../api/Kazagumo.js";

export default class Raahi extends Client {
  [x: string]: any;
  shoukaku: any; // Explicitly declare to avoid type errors
  constructor() {
    super({
      intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildInvites,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildPresences,
      ],
      partials: [
        Partials.Channel,
        Partials.GuildMember,
        Partials.Message,
        Partials.User,
        Partials.Reaction,
      ],
      allowedMentions: {
        repliedUser: false,
        parse: ["everyone", "roles", "users"],
      },
      failIfNotExists: true,
      shards: getInfo().SHARD_LIST,
      shardCount: getInfo().TOTAL_SHARDS,
    });

    // Futuristic AI-powered core modules
    this.config = new RaahiConfig();
    this.emoji = new RaahiEmoji(this);
    this.kazagumo = new RaahiKazagumo(this);
    this.shoukaku = this.kazagumo.shoukaku; // Use the internal Shoukaku instance
    this.spotify = new RaahiSpotify(this);
    this.cluster = new ClusterClient(this);
    this.logger = new RaahiLogger(this);
    this.utils = new RaahiUtils(this);
    this.api = new RaahiApi(this);
    this.events = new RaahiEvents(this).loadEvents();
    this.commands = new RaahiCommands(this).loadCommands();

    // Futuristic: Auto AI recommendations & smart queue system
    this.futuristicAI = {
      enabled: true,
      autoRecommend: true,
      smartQueue: true,
      cosmicMode: true,
    };
  }

  start() {
    this.logger.log(`🌌 ✨ Raahi Futuristic v6.0 initialized! Connecting to the quantum realm...`);
    return super.login(this.config.token);
  }
}
