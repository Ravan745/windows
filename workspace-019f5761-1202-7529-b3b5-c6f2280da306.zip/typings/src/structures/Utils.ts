import {
  ActionRowBuilder,
  AttachmentBuilder,
  ButtonBuilder,
  EmbedBuilder,
  StringSelectMenuBuilder,
  resolvePartialEmoji,
} from "discord.js";
import createId from "create-id";
import {
  getServerPremiumStatus,
  getUserPremStatus,
  getPremTime,
  getServerPremTime,
  getServerPrem,
  getActivator,
  deleteServerPrem,
  listfavs,
} from "../api/db/premium.js";
import { getHex, removeHex } from "../api/db/embeds.js";
import {
  addDjRole,
  checkDj,
  createDjChannel,
  deleteDjChannel,
  getDjChannel,
  getDjRole,
  getDjSetup,
  getPlayerMode,
  playType,
  removeDjRole,
  updatePlayType,
  updatePlayerMode,
} from "../api/db/dj.js";
import {
  AddGlobalNp,
  RemoveGlobalNp,
  addServerNp,
  globalNpSelection,
  removeServerNp,
  resetNp,
  serverNpSelection,
  updatePrefix,
} from "../api/db/prefix.js";
import RaahiTrack from "../base/RaahiTrack.js";
import {
  addBypassAdmins,
  addBypassMods,
  addIgnore,
  checkBypassAdmins,
  checkBypassMods,
  checkIgnore,
  disable247,
  disableAutoplay,
  enable247,
  enableAutoplay,
  get247,
  getAutoplay,
  listIgnores,
  removeAdminBypass,
  removeBypassMods,
  removeIgnore,
  resetIgnore,
} from "../api/db/settings.js";
import prettyMilliseconds from "pretty-ms";

export default class RaahiUtils {
  client: any;
  constructor(client: any) {
    this.client = client;
  }

  public embed() {
    return new EmbedBuilder().setColor(this.client.config.color);
  }

  public successEmbed() {
    return new EmbedBuilder().setColor("#98FF98");
  }

  public errorEmbed() {
    return new EmbedBuilder().setColor("#FF6961");
  }

  public premiumEmbed(guildID?: string) {
    if (!guildID) return new EmbedBuilder().setColor(this.client.config.color);
    if (
      this.checkServerPrem(guildID) === false &&
      this.checkServerPremStatus(guildID) === false
    ) {
      removeHex(guildID);
      return new EmbedBuilder().setColor(this.client.config.color);
    } else {
      try {
        let hex = getHex(guildID);
        if (hex.HEXCODE === null)
          return new EmbedBuilder().setColor(this.client.config.color);
        else
          return new EmbedBuilder().setColor(
            hex.HEXCODE ? hex.HEXCODE : this.client.config.color
          );
      } catch (e) {
        removeHex(guildID);
        return new EmbedBuilder().setColor(this.client.config.color);
      }
    }
  }

  // ✨ GEN Z SLAY MUSIC CARD (main character energy)
  public cuteMusicCard(track: any, requester?: any) {
    const title = track.info.title.length > 52 
      ? track.info.title.substring(0, 49) + "..." 
      : track.info.title;

    const card = new EmbedBuilder()
      .setColor(this.client.config.color)
      .setAuthor({
        name: `🎵 Now Playing • Slay Edition`,
        iconURL: "https://cdn.discordapp.com/emojis/1129817857727942738.gif",
      })
      .setTitle(`✨ ${title} ✨`)
      .setURL(track.info.uri || this.client.config.voteUrl)
      .setDescription(
        `🎤 **${track.info.author}** just dropped heat 🔥\n` +
        `⏱️ **${this.humanize(track.info.length)}**  •  🔊 **80%**  •  🎧 **${track.info.sourceName || "YT Music"}**\n\n` +
        `💅 *This one ate and left no crumbs bestie*`
      )
      .setImage(
        track.info.identifier 
          ? `https://img.youtube.com/vi/${track.info.identifier}/maxresdefault.jpg`
          : `https://i.imgur.com/8vL9v3K.png`
      )
      .setThumbnail(
        track.info.identifier 
          ? `https://img.youtube.com/vi/${track.info.identifier}/hqdefault.jpg`
          : (requester?.displayAvatarURL?.({ dynamic: true }) || this.client.user.displayAvatarURL())
      )
      .setFooter({
        text: `🚀 Raahi Futuristic AI • Main Character Energy 💖`,
        iconURL: this.client.user.displayAvatarURL(),
      });

    return card;
  }

  // ✨ GEN Z SEARCHING CARD (we're so back)
  public cuteSearchingCard(query: string) {
    return new EmbedBuilder()
      .setColor("#FF85A2")
      .setAuthor({
        name: `🔍 Hunting for the vibe...`,
        iconURL: this.client.user.displayAvatarURL(),
      })
      .setDescription(
        `💅 Looking for **\`${query}\`** bestie...\n\n` +
        `✨ *Our AI is cooking up the most bussin' track for you rn* 🔥\n` +
        `🫡 *Hold on we're literally in the trenches finding this*`
      )
      .setFooter({
        text: `Raahi • No Cap Music AI 💖`,
        iconURL: this.client.user.displayAvatarURL(),
      });
  }

  public genPremId() {
    let prefix = "raahi_";
    let suffix = "_op";
    let length = 10;
    return createId(prefix, suffix, length);
  }

  public checkUserPrem(id: string): boolean {
    let stat = getUserPremStatus(id);
    if (stat.USER === null) return false;
    else return true;
  }

  public checkServerPremStatus(id: string) {
    let stat = getServerPremiumStatus(id);
    if (stat.STATUS === 1) return true;
    else return false;
  }

  public checkPremTime(id: string) {
    let stat = getPremTime(id);
    if (stat.TIME === 0) return 0;
    else return stat.TIME;
  }

  public checkServerPremTime(id: string) {
    let stat = getServerPremTime(id);
    if (stat.TIME === null) return 0;
    else return stat.TIME;
  }

  public checkServerPrem(id: string) {
    let check = getServerPrem(id);
    if (check.SERVER !== null) return true;
    else return false;
  }

  public checkActivator(id: string) {
    let check = getActivator(id);
    if (check.USER !== null) return check.USER;
    else return null;
  }

  public deleteServerPrem(id: string) {
    deleteServerPrem(id);
    return true;
  }

  public actionRow(components: any[]) {
    return new ActionRowBuilder().addComponents(components);
  }

  public button(
    base: string,
    label: string | null,
    style: number,
    customId: string | null,
    url: string | null,
    emoji?: any
  ) {
    if (base === "custom_id") {
      let button = new ButtonBuilder().setCustomId(customId!).setStyle(style);
      let emojiSet = false;
      if (emoji !== undefined && emoji !== null) {
        let parsed = resolvePartialEmoji(emoji);
        if (parsed) {
          if (!parsed.id || (parsed.id && Boolean(this.client?.emojis?.cache?.has(parsed.id)))) {
            button.setEmoji(emoji);
            emojiSet = true;
          } else {
            let fallback = this.getFallbackEmoji(customId || "", (parsed as any).name || "");
            if (fallback) {
              button.setEmoji(fallback);
              emojiSet = true;
            }
          }
        }
      }
      if (label !== null && label !== undefined) {
        button.setLabel(label);
      } else if (!emojiSet) {
        button.setLabel(this.getFallbackLabel(customId || ""));
      }
      return button;
    } else if (base === "link") {
      let button = new ButtonBuilder().setLabel(label || "Link").setURL(url!).setStyle(5);
      if (emoji !== undefined && emoji !== null) {
        let parsed = resolvePartialEmoji(emoji);
        if (parsed) {
          if (!parsed.id || (parsed.id && Boolean(this.client?.emojis?.cache?.has(parsed.id)))) {
            button.setEmoji(emoji);
          } else {
            let fallback = this.getFallbackEmoji("link", (parsed as any).name || "");
            if (fallback) button.setEmoji(fallback);
          }
        }
      }
      return button;
    }
  }

  public menuOption(
    label: string,
    emoji: any,
    description: string,
    value: string
  ) {
    const ob: {
      label: string;
      description: string;
      value: string;
      emoji?: any;
    } = {
      label: label,
      description: description,
      value: value,
    };
    if (emoji !== null && emoji !== undefined) {
      let parsed = resolvePartialEmoji(emoji);
      if (parsed) {
        if (!parsed.id || (parsed.id && Boolean(this.client?.emojis?.cache?.has(parsed.id)))) {
          ob.emoji = emoji;
        } else {
          let fallback = this.getFallbackEmoji(value || "", (parsed as any).name || "");
          if (fallback) ob.emoji = fallback;
        }
      }
    }
    return ob;
  }

  public getFallbackEmoji(idStr: string = "", nameStr: string = ""): string | undefined {
    if (typeof this.client?.emoji?.getFallback === "function") {
      const res = this.client.emoji.getFallback(idStr, nameStr);
      if (res) return res;
    }
    const s = `${idStr} ${nameStr}`.toLowerCase();
    if (s.includes("pause") || s.includes("resume") || s.includes("play")) return "⏸️";
    if (s.includes("skip") || s.includes("next") || s.includes("slip") || s.includes("last") || (s.includes("forward") && !idStr.toLowerCase().includes("forward"))) return "⏭️";
    if (s.includes("prev") || s.includes("back") || s.includes("right")) return "⏮️";
    if (s.includes("stop")) return "⏹️";
    if (s.includes("loop") || s.includes("repeat") || s.includes("request")) return "🔁";
    if (s.includes("shuffle") || s.includes("suffle")) return "🔀";
    if (s.includes("vollow") || s.includes("volminus") || s.includes("lower")) return "🔉";
    if (s.includes("volhigh") || s.includes("volplus") || s.includes("higher") || s.includes("vol")) return "🔊";
    if (s.includes("forward")) return "⏩";
    if (s.includes("backward")) return "⏪";
    if (s.includes("fav") || s.includes("heart")) return "❤️";
    if (s.includes("autoplay")) return "♾️";
    if (s.includes("reset")) return "♻️";
    if (s.includes("filter") || s.includes("8d") || s.includes("bassboost") || s.includes("nightcore") || s.includes("vibrato")) return "🎵";
    if (s.includes("tick") || s.includes("yes") || s.includes("confirm")) return "✅";
    if (s.includes("cross") || s.includes("no") || s.includes("cancel") || s.includes("decline")) return "❌";
    if (s.includes("vote")) return "⭐";
    if (s.includes("invite") || s.includes("support") || s.includes("link")) return "🔗";
    if (s.includes("info")) return "ℹ️";
    if (s.includes("queue")) return "📜";
    if (s.includes("home")) return "🏠";
    if (s.includes("music")) return "🎶";
    if (s.includes("utility")) return "🛠️";
    if (s.includes("allcommands") || s.includes("commands")) return "📋";
    if (s.includes("spoti")) return "🟢";
    if (s.includes("deez")) return "🟣";
    if (s.includes("sound")) return "🟠";
    if (s.includes("default") || s.includes("youtube")) return "▶️";
    return undefined;
  }

  public getFallbackLabel(customIdOrName: string = ""): string {
    const s = customIdOrName.toLowerCase();
    if (s.includes("pause")) return "Pause/Resume";
    if (s.includes("skip") || s.includes("next")) return "Skip";
    if (s.includes("prev") || s.includes("back")) return "Previous";
    if (s.includes("stop")) return "Stop";
    if (s.includes("loop") || s.includes("repeat")) return "Loop";
    if (s.includes("shuffle")) return "Shuffle";
    if (s.includes("vollow") || s.includes("lower")) return "Vol -";
    if (s.includes("volhigh") || s.includes("higher") || s.includes("vol")) return "Vol +";
    if (s.includes("forward")) return "Forward";
    if (s.includes("backward")) return "Backward";
    if (s.includes("fav")) return "Favorite";
    if (s.includes("autoplay")) return "Autoplay";
    if (s.includes("filter")) return "Filter";
    if (s.includes("yes") || s.includes("confirm")) return "Confirm";
    if (s.includes("no") || s.includes("cancel") || s.includes("decline")) return "Decline";
    return "Select";
  }

  public menu(placeholder: string, customId: string, options: any) {
    return new StringSelectMenuBuilder()
      .setCustomId(customId)
      .setPlaceholder(placeholder)
      .setOptions(options);
  }

  public getPlayerMode(id: string) {
    let get = getPlayerMode(id);
    return get.MODE;
  }

  public updatePlayerMode(id: string, mode: string) {
    updatePlayerMode(id, mode);
    return true;
  }

  public checkDjSetup(id: string) {
    let get = checkDj(id);
    if (get === true) return true;
    else return false;
  }

  public djSetupChannel(id: string) {
    let get = getDjChannel(id);
    return get.CHANNEL;
  }

  public addGlobalNp(id: string, res: string) {
    AddGlobalNp(id, res);
    return true;
  }

  public removeGlobalNp(id: string) {
    RemoveGlobalNp(id);
    return true;
  }

  public checkGlobalNp(id: string) {
    if (globalNpSelection(id) === true) return true;
    else return false;
  }

  public checkGuildNp(guildId: string, user: string) {
    let check = serverNpSelection(user, guildId);
    if (check === true) return true;
    else return false;
  }

  public addGuildNp(guild: string, user: string, reason: string) {
    addServerNp(user, guild, reason);
    return true;
  }

  public removeGuildNp(user: string, guild: string) {
    removeServerNp(user, guild);
    return true;
  }

  public createDj(guildId: string, channelId: string, messageId: string) {
    createDjChannel(guildId, channelId, messageId);
    return true;
  }

  public deleteDj(guildId: string) {
    deleteDjChannel(guildId);
    return true;
  }

  public getDj(guildId: string) {
    let get = getDjSetup(guildId);
    if (get.CHANNEL !== null && get.MESSAGE !== null) return get;
    else return null;
  }

  public getdjrole(guildId: string) {
    let get = getDjRole(guildId);
    if (get.ROLE !== null) return get.ROLE;
    else return null;
  }

  public addDjRole(guild: string, role: string) {
    addDjRole(guild, role);
    return true;
  }

  public deleteDjRole(guild: string) {
    removeDjRole(guild);
    return true;
  }

  public getPlay(guild: string) {
    let get = playType(guild);
    if (get.TYPE === null) {
      this.updatePlay(guild, "buttons");
      return null;
    } else return get.TYPE;
  }

  public updatePlay(guild: string, type: string) {
    updatePlayType(guild, type);
    return;
  }

  public checkUrl(x: string) {
    try {
      new URL(x);
      return true;
    } catch (e) {
      return false;
    }
  }

  public track(tr: any) {
    return new RaahiTrack(tr);
  }

  public player(node: any, options: any) {
    if (typeof node?.joinChannel === "function") return node.joinChannel(options);
    return this.client.shoukaku.joinVoiceChannel(options);
  }

  /**
   * Resolve a query through Shoukaku v4's REST API and normalise the
   * response into the shape the rest of the codebase expects
   * ({ loadType, tracks, playlist }).
   *
   * Shoukaku v4 returns `{ loadType, data }` where `data` holds the
   * track / playlist / search results (there is no `.tracks` on the raw
   * response and loadType values are lowercase), so we map it back to the
   * legacy string loadTypes the commands rely on.
   */
  public async resolve(
    node: any,
    query: string
  ): Promise<{ loadType: string; tracks: any[]; playlist: boolean }> {
    if (!node?.rest?.resolve)
      return { loadType: "LOAD_FAILED", tracks: [], playlist: false };
    const res = await node.rest.resolve(query).catch(() => null);
    if (!res) return { loadType: "LOAD_FAILED", tracks: [], playlist: false };
    switch (res.loadType) {
      case "track":
        return { loadType: "TRACK_LOADED", tracks: [res.data], playlist: false };
      case "playlist":
        return {
          loadType: "PLAYLIST_LOADED",
          tracks: res.data?.tracks || [],
          playlist: true,
        };
      case "search":
        return { loadType: "SEARCH_RESULT", tracks: res.data || [], playlist: false };
      case "empty":
        return { loadType: "NO_MATCHES", tracks: [], playlist: false };
      case "error":
        return { loadType: "LOAD_FAILED", tracks: [], playlist: false };
      default:
        return { loadType: "LOAD_FAILED", tracks: [], playlist: false };
    }
  }

  public resetNoPrefix() {
    return resetNp();
  }

  public findFavs(user: string, track: any) {
    let list = listfavs(user);
    if (list.includes(track.info.title)) return true;
    else return false;
  }

  public getAutoPlay(guild: string) {
    if (getAutoplay(guild).SETTING === 1) return true;
    else return false;
  }

  public updateAutoPlay(guild: string) {
    if (getAutoplay(guild).SETTING === 1) {
      disableAutoplay(guild);
      return false;
    } else {
      enableAutoplay(guild);
      return true;
    }
  }

  public get247(guild: string) {
    let get = get247(guild);
    if (get.SETTING === 1) return true;
    else return false;
  }

  public disable247(guild: string) {
    disable247(guild);
    return true;
  }

  public updatePrefix(guild: string, prefix: string) {
    updatePrefix(guild, prefix);
    return true;
  }

  public enable247(guild: string, voiceId: string, textId: string) {
    enable247(guild, voiceId, textId);
    return true;
  }

  public humanize(duration: number) {
    return prettyMilliseconds(duration, { colonNotation: true });
  }

  public removeServerNp(user: string, guild: string) {
    removeServerNp(user, guild);
    return true;
  }

  public attachment(attach: any) {
    return new AttachmentBuilder(attach)
      .setDescription(`Raahi Is God`)
      .setName(`RaahiNowPlaying.png`);
  }

  public checkIgnore(guild: string, channel: string) {
    let check = checkIgnore(channel, guild);
    if (check === true) return true;
    else return false;
  }

  public addIgnore(guild: string, channel: string) {
    addIgnore(channel, guild);
    return;
  }

  public removeIgnore(guild: string, channel: string) {
    removeIgnore(channel, guild);
    return;
  }

  public getIgnoreList(guild: string) {
    return listIgnores(guild);
  }

  public checkBypassAdmins(guild: string) {
    let check = checkBypassAdmins(guild);
    if (check.BYPASS_ADMINS === 1) return true;
    return false;
  }

  public checkBypassMods(guild: string) {
    let check = checkBypassMods(guild);
    if (check.BYPASS_MODS === 1) return true;
    return false;
  }

  public addBypassAdmins(guild: string) {
    addBypassAdmins(guild);
    return;
  }

  public removeBypassAdmins(guild: string) {
    removeAdminBypass(guild);
    return;
  }

  public addBypassMods(guild: string) {
    addBypassMods(guild);
    return;
  }

  public removeBypassMods(guild: string) {
    removeBypassMods(guild);
    return;
  }

  public resetIgnore(guild: string) {
    resetIgnore(guild);
    return;
  }

  // ==================== SAFE INTERACTION HELPERS (Fixes deprecation & bugs) ====================

  public async safeReply(interaction: any, options: any) {
    try {
      if (interaction.replied || interaction.deferred) {
        return await interaction.followUp(options).catch(() => {});
      }
      return await interaction.reply(options).catch(() => {});
    } catch (e) {
      return null;
    }
  }

  public async safeUpdate(interaction: any, options: any) {
    try {
      if (!interaction.replied && !interaction.deferred) {
        await interaction.deferUpdate().catch(() => {});
      }
      return await interaction.editReply(options).catch(() => {});
    } catch (e) {
      return null;
    }
  }

  public async safeDeferUpdate(interaction: any) {
    try {
      if (!interaction.replied && !interaction.deferred) {
        return await interaction.deferUpdate().catch(() => {});
      }
    } catch (_) {}
  }

  public async safeDeferReply(interaction: any, ephemeral = false) {
    try {
      if (!interaction.replied && !interaction.deferred) {
        return await interaction.deferReply({ ephemeral }).catch(() => {});
      }
    } catch (_) {}
  }

  // ==================== SAFE BOT MEMBER ACCESS ====================
  public getBotMember(guild: any) {
    return guild?.members?.me || guild?.members?.cache?.get(this.client.user.id) || null;
  }

  // ==================== MODERN PROGRESS BAR ====================
  public progressBar(current: number, total: number, size = 15) {
    const percent = current / total;
    const progress = Math.round(size * percent);
    const emptyProgress = size - progress;

    const progressText = "▰".repeat(progress);
    const emptyProgressText = "▱".repeat(emptyProgress);

    const percentage = Math.round(percent * 100);
    return `\`${progressText}${emptyProgressText}\` **${percentage}%**`;
  }
}
