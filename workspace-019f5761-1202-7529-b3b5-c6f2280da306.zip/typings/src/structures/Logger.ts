import chalk from "chalk";
import moment from "moment";

function getTime() {
  return `[${moment().utcOffset("+5:30").format(`DD-MM-YYYY | hh:mm:ss`)}]`;
}

export default class RaahiLogger {
  client: any;
  constructor(client: any) {
    this.client = client;
  }
  public log(x: any) {
    return console.log(
      chalk.bgHex("#1c1a1b").hex("#FF85A2").bold(getTime()) +
        " | " +
        chalk.bold("[") +
        chalk.bgHex("#FF85A2").hex("#1c1a1b").bold("LOG") +
        chalk.bold("]") +
        " | " +
        x
    );
  }
  public debug(x: any) {
    return console.debug(
      chalk.bgHex("#1c1a1b").hex("#E0B0FF").bold(getTime()) +
        " | " +
        chalk.bold("[") +
        chalk.bgHex("#E0B0FF").hex("#1c1a1b").bold("DEBUG") +
        chalk.bold("]") +
        " | " +
        x
    );
  }
  public ready(x: any) {
    return console.log(
      chalk.bgHex("#1c1a1b").hex("#98FF98").bold(getTime()) +
        " | " +
        chalk.bold("[") +
        chalk.bgHex("#98FF98").hex("#1c1a1b").bold("READY") +
        chalk.bold("]") +
        " | " +
        x
    );
  }

  public warn(x: any) {
    return console.warn(
      chalk.bgHex("#1c1a1b").hex("#FFD700").bold(getTime()) +
        " | " +
        chalk.bold("[") +
        chalk.bgHex("#FFD700").hex("#1c1a1b").bold("WARN") +
        chalk.bold("]") +
        " | " +
        x
    );
  }

  public error(x: any) {
    return console.error(
      chalk.bgHex("#1c1a1b").hex("#FF6961").bold(getTime()) +
        " | " +
        chalk.bold("[") +
        chalk.bgHex("#FF6961").hex("#1c1a1b").bold("ERROR") +
        chalk.bold("]") +
        " | " +
        x
    );
  }
}
