import { Collection } from "discord.js";
import * as fs from "fs";
export default class RaahiCommands {
  client: any;
  loaded: boolean;
  messages: Collection<unknown, unknown>;
  constructor(client: any) {
    this.client = client;
    this.loaded = false;
    this.messages = new Collection();
  }
  public loadCommands() {
    if (this.loaded) return this;
    fs.readdirSync(`./build/src/commands/`).forEach((dir) => {
      fs.readdirSync(`./build/src/commands/${dir}`)
        .filter((x) => x.endsWith(".js"))
        .forEach(async (file) => {
          let command = (await import(`../commands/${dir}/${file}`)).default;
          let RaahiCommand = new command(this.client);
          if (!RaahiCommand || !RaahiCommand.name) return;
          this.messages.set(RaahiCommand.name, RaahiCommand);
          this.client.logger.debug(
            `Command Loaded: ${RaahiCommand.name} loaded!`
          );
        });
    });
    this.client.logger.log(`Loaded Client Commands Successfully!`);
    this.loaded = true;
    return this;
  }
}
