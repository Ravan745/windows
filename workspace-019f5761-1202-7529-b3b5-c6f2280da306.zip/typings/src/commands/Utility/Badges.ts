import RaahiCommand from "../../base/RaahiCommand.js";

export default class Badges extends RaahiCommand {
  owner: string;
  developer: string;
  staff: string;
  codev: string;
  supporter: string;
  admin: string;
  vip: string;
  friend: string;
  user: string;
  bug: string;
  mod: string;
  communityManager: string;
  constructor(client?: any) {
    super(client);
    this.name = "badges";
    this.aliases = ["badge", "achievements"];
    this.cat = "utility";
    this.desc = "Shows all the Badges and achievements available on Raahi";
    this.usage = "badges";
    this.owner = "1129669328371990579";
    this.developer = "1129667888127680592";
    this.communityManager = "";
    this.staff = "1065489475028930642";
    this.admin = "1065488468999929936";
    this.codev = "1129668221574844497";
    this.supporter = "1071291114411270217";
    this.vip = "1129668638866153482";
    this.friend = "";
    this.user = "1053336995608403979";
    this.bug = "1129667685601513562";
    this.mod = "1107839131473678416";
    this.exec = async (message: any, args: any, prefix: any) => {
      let em = this.client.utils
        .premiumEmbed(message.guildId)
        .setTitle(`${this.client?.user?.username || "Raahi"} Badges & Achievements`)
        .setDescription(
          `Join our **[Support Server](${this.client.config.server})** to claim Badges on your **Profile**!`
        )
        .addFields([
          {
            name: `👑 Team & Developers`,
            value: `${this.client.emoji.badges.owner} **Owner**\n${this.client.emoji.badges.dev} **Developer**\n${this.client.emoji.badges.codev} **Co-Developer**`,
            inline: true,
          },
          {
            name: `🛡️ Staff & Moderation`,
            value: `${this.client.emoji.badges.admin} **Admin**\n${this.client.emoji.badges.staff} **Staff**\n${this.client.emoji.badges.mod} **Moderator**`,
            inline: true,
          },
          {
            name: `⭐ Supporters & Users`,
            value: `${this.client.emoji.badges.vip} **VIP**\n${this.client.emoji.badges.supporter} **Supporter**\n${this.client.emoji.badges.premiumUser} **Premium User**\n${this.client.emoji.badges.friend} **Friend**`,
            inline: true,
          },
        ])
        .setThumbnail(this.client.user?.displayAvatarURL?.() || "");

      return message.reply({ embeds: [em] });
    };
  }
}
