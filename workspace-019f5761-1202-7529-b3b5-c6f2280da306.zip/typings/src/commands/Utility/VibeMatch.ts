import { getUserVibe } from "../../api/db/stats.js";
import RaahiCommand from "../../base/RaahiCommand.js";

export default class VibeMatch extends RaahiCommand {
  constructor(client: any) {
    super(client);
    this.name = "match";
    this.aliases = ["vibematch"];
    this.cat = "utility";
    this.desc = "Check your music compatibility with another user! 👯💖";
    this.usage = "match <@user>";
    
    this.exec = async (message: any, args: any) => {
      const target = message.mentions.users.first() || this.client.users.cache.get(args[0]);
      if (!target) return message.reply({ content: "💅 **Bestie!** Mention someone to check your vibe match!" });
      if (target.id === message.author.id) return message.reply({ content: "You're already 100% in sync with yourself queen! 💅" });

      const user1Vibe = getUserVibe(message.author.id);
      const user2Vibe = getUserVibe(target.id);

      if (!user1Vibe.length || !user2Vibe.length) {
          return message.reply({ content: "🥺 One of you hasn't played enough songs yet! Keep vibing and try again." });
      }

      // Calculate common tracks/authors
      const common = user1Vibe.filter(v1 => 
        user2Vibe.some(v2 => v1.TITLE === v2.TITLE || v1.AUTHOR === v2.AUTHOR)
      );

      let score = Math.floor((common.length / Math.max(user1Vibe.length, user2Vibe.length)) * 100) + 20;
      if (score > 100) score = 100;

      let verdict = "Absolute Multiverse Soulmates! 🌌✨";
      if (score < 40) verdict = "Vibing on different frequencies... for now! 📡";
      else if (score < 70) verdict = "Definitely sharing the same playlist energy! 🔥";

      const embed = this.client.utils.premiumEmbed(message.guildId)
        .setTitle("💖 VIBE MATCH RESULTS")
        .setDescription(
            `👥 **Users:** ${message.author} & ${target}\n` +
            `📈 **Compatibility:** \`${score}%\`\n\n` +
            `✨ **Verdict:** *${verdict}*\n` +
            `💅 *Common Grounds:* \`${common.length > 0 ? common.slice(0, 3).map(t => t.TITLE).join(", ") : "Main Character Energy"}\``
        );

      return message.reply({ embeds: [embed] });
    };
  }
}
