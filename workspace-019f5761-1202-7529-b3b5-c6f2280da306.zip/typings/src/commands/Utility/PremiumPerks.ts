import RaahiCommand from "../../base/RaahiCommand.js";
import { hasPremium, getPremiumPerks, activatePremium } from "../../api/db/premiumPerks.js";

export default class RaahiPremiumPerks extends RaahiCommand {
  constructor(client: any) {
    super(client);
    this.name = "premium";
    this.aliases = ["perks", "vip"];
    this.cat = "utility";
    this.desc = "Check your premium perks or activate (Owner only)";

    this.exec = async (message: any, args: any) => {
      if (args[0] === "activate" && this.client.config.owners.includes(message.author.id)) {
        const user = message.mentions.users.first() || message.author;
        activatePremium(user.id, 30);
        return message.reply({ content: `✅ Premium activated for ${user.tag}!` });
      }

      const perks = getPremiumPerks(message.author.id);
      const isPremium = hasPremium(message.author.id);

      const embed = this.client.utils.premiumEmbed(message.guildId)
        .setTitle(isPremium ? "💎 Your Premium Perks" : "🌟 Free Tier")
        .setDescription(
          isPremium 
            ? `**Queue Limit:** Unlimited\n**Custom Images:** ✅\n**Priority Queue:** ✅\n**All Filters:** ✅\n**No Cooldowns:** ✅`
            : `**Queue Limit:** 100\n**Custom Images:** ❌\n**Priority Queue:** ❌\n**All Filters:** ❌\n**No Cooldowns:** ❌\n\nUse premium to unlock everything!`
        );

      message.reply({ embeds: [embed] });
    };
  }
}
