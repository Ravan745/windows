import RaahiCommand from "../../base/RaahiCommand.js";

export default class RaahiSettings extends RaahiCommand {
  constructor(client: any) {
    super(client);
    this.name = "settings";
    this.cat = "utility";
    this.desc = "Server settings (Admin/Owner only)";
    this.manage = true;

    this.exec = async (message: any, args: any, prefix: any) => {
      const sub = args[0]?.toLowerCase();

      if (!sub) {
        return message.reply({
          embeds: [this.client.utils.premiumEmbed(message.guildId).setDescription(
            `**Server Settings**\n` +
            `\`${prefix}settings 247 <on/off>\`\n` +
            `\`${prefix}settings autoplay <on/off>\`\n` +
            `\`${prefix}settings djrole <@role>\`\n` +
            `\`${prefix}settings prefix <newprefix>\``
          )]
        });
      }

      // Check permissions
      if (!message.member.permissions.has("ManageGuild") && !this.client.config.owners.includes(message.author.id)) {
        return message.reply({ content: "You need Manage Server permission!" });
      }

      if (sub === "247") {
        const mode = args[1]?.toLowerCase();
        if (mode === "on") {
          this.client.utils.enable247(message.guildId, message.member.voice.channel?.id, message.channel.id);
          return message.reply({ content: "✅ 24/7 mode enabled!" });
        } else if (mode === "off") {
          this.client.utils.disable247(message.guildId);
          return message.reply({ content: "❌ 24/7 mode disabled!" });
        }
      }

      if (sub === "autoplay") {
        const mode = args[1]?.toLowerCase();
        const newMode = this.client.utils.updateAutoPlay(message.guildId);
        return message.reply({ content: `Autoplay is now ${newMode ? "ON" : "OFF"}` });
      }

      if (sub === "djrole") {
        const role = message.mentions.roles.first();
        if (!role) return message.reply({ content: "Mention a role!" });
        this.client.utils.addDjRole(message.guildId, role.id);
        return message.reply({ content: `DJ role set to ${role}` });
      }

      if (sub === "prefix") {
        const newPrefix = args[1];
        if (!newPrefix) return message.reply({ content: "Give me a new prefix!" });
        this.client.utils.updatePrefix(message.guildId, newPrefix);
        return message.reply({ content: `Prefix changed to \`${newPrefix}\`` });
      }
    };
  }
}
