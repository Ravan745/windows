import RaahiCommand from "../../base/RaahiCommand.js";

export default class Help extends RaahiCommand {
  constructor(client: any) {
    super(client);
    this.name = "help";
    this.aliases = ["h", "commands"];
    this.cat = "utility";
    this.desc = "📚 Browse Raahi's full command list with an interactive help menu";
    this.usage = "help [command/category]";
    this.vc = false;
    this.dev = false;
    this.premium = {
      guild: false,
      user: false,
    };

    this.exec = async (message: any, args: any, prefix: any) => {
      // Invite link built from the bot's own application id
      const inviteUrl = `https://discord.com/oauth2/authorize?client_id=${this.client.user.id}&permissions=8&scope=bot%20applications.commands`;
      const banner = `https://media.discordapp.net/attachments/1088387181665591346/1137284441568444476/AVON_BANNER_3.png?width=1440&height=360`;
      const guildIcon = message.guild?.iconURL?.({ dynamic: true }) || this.client.user.displayAvatarURL();

      // Grab the command names of a category, sorted & backticked
      const getCmds = (cat: string): string[] =>
        this.client.commands.messages
          .filter((x: any) => x.cat && x.cat === cat)
          .map((x: any) => `\`${x.name}\``)
          .sort();

      // Build a tidy embed for a single category
      const makeCatEmbed = (cat: string, title: string, emoji: string) => {
        const cmds = getCmds(cat);
        return this.client.utils
          .premiumEmbed(message.guildId)
          .setAuthor({
            name: `${this.client.user.username} • ${title}`,
            iconURL: this.client.user.displayAvatarURL(),
          })
          .setTitle(`${emoji} ${title} [${cmds.length}]`)
          .setDescription(
            cmds.length
              ? cmds.join(", ")
              : "No commands found in this category."
          )
          .setThumbnail(this.client.user.displayAvatarURL())
          .setFooter({
            text: `Use ${prefix}help <command> for details • Made with 🔥 By Raahi Development`,
            iconURL: message.author.displayAvatarURL({ dynamic: true }),
          });
      };

      // Build the "all commands" mega-embed
      const makeAllEmbed = () => {
        const cats = [
          { cat: "music", title: "Music", emoji: this.client.emoji.helpMenu.music },
          { cat: "filters", title: "Filters", emoji: this.client.emoji.helpMenu.filters },
          { cat: "utility", title: "Utility", emoji: this.client.emoji.helpMenu.utility },
          { cat: "info", title: "Information", emoji: this.client.emoji.helpMenu.info },
          { cat: "dev", title: "Owner", emoji: "👑" },
        ];
        return this.client.utils
          .premiumEmbed(message.guildId)
          .setAuthor({
            name: `${this.client.user.username}`,
            iconURL: this.client.user.displayAvatarURL(),
          })
          .setTitle(`${this.client.emoji.helpMenu.allCommands} All Commands [${this.client.commands.messages.size}]`)
          .setDescription(`Here's the complete command list of **${this.client.user.username}** 🎶`)
          .addFields(
            cats.map(({ cat, title, emoji }) => {
              const cmds = getCmds(cat);
              return {
                name: `${emoji} ${title} [${cmds.length}]`,
                value: cmds.join(", ") || "None",
              };
            })
          )
          .addFields([
            {
              name: `🔗 Links`,
              value: `**[Support](${this.client.config.server}) • [Invite](${inviteUrl}) • [Vote](${this.client.config.voteUrl}) • [Premium](${this.client.config.server})**`,
            },
          ])
          .setImage(banner)
          .setThumbnail(this.client.user.displayAvatarURL())
          .setFooter({
            text: `Made with 🔥 By Raahi Development`,
            iconURL: guildIcon,
          });
      };

      // ───────────────────────── NO ARGS → INTERACTIVE MENU ─────────────────────────
      if (!args[0]) {
        const em = this.client.utils
          .premiumEmbed(message.guildId)
          .setAuthor({
            name: `${this.client.user.username}`,
            iconURL: this.client.user.displayAvatarURL(),
          })
          .setTitle(`✨ ${this.client.user.username}'s Help Menu ✨`)
          .setDescription(
            `Hey **${message.author.username}**! I'm **${this.client.user.username}** — the true definition of a bussin' music bot 🎧✨\n` +
              `Advanced reconnection, multiple search engines, and crisp quality music for your server.\n\n` +
              `🔹 **Prefix:** \`${prefix}\`\n` +
              `🔹 **Total Commands:** \`${this.client.commands.messages.size}\`\n` +
              `🔹 **Command Info:** \`${prefix}help <command>\`\n\n` +
              `Pick a category below to explore my commands 👇`
          )
          .addFields([
            {
              name: `${this.client.emoji.helpMenu.music} Music`,
              value: `\`${prefix}help music\` — Play, queue, skip & more`,
              inline: true,
            },
            {
              name: `${this.client.emoji.helpMenu.filters} Filters`,
              value: `\`${prefix}help filters\` — Audio filters`,
              inline: true,
            },
            {
              name: `${this.client.emoji.helpMenu.utility} Utility`,
              value: `\`${prefix}help utility\` — Bot utilities`,
              inline: true,
            },
            {
              name: `${this.client.emoji.helpMenu.info} Information`,
              value: `\`${prefix}help info\` — Bot stats & info`,
              inline: true,
            },
            {
              name: `${this.client.emoji.helpMenu.allCommands} All Commands`,
              value: `\`${prefix}help all\` — Full command list`,
              inline: true,
            },
            {
              name: `🔗 Links`,
              value: `**[Support](${this.client.config.server}) • [Invite](${inviteUrl}) • [Vote](${this.client.config.voteUrl}) • [Premium](${this.client.config.server})**`,
              inline: true,
            },
          ])
          .setThumbnail(this.client.user.displayAvatarURL())
          .setImage(banner)
          .setFooter({
            text: `Made with 🔥 By Raahi Development`,
            iconURL: message.author.displayAvatarURL({ dynamic: true }),
          });

        // Select menu options
        const menuOptionHome = this.client.utils.menuOption(
          `Home`,
          this.client.emoji.helpMenu.home,
          `Return to the main help menu`,
          `help-home`
        );
        const menuOptionMusic = this.client.utils.menuOption(
          `Music`,
          this.client.emoji.helpMenu.music,
          `Commands to play & manage music`,
          `music-help`
        );
        const menuOptionFilters = this.client.utils.menuOption(
          `Filters`,
          this.client.emoji.helpMenu.filters,
          `Audio filter commands`,
          `filter-help`
        );
        const menuOptionUtility = this.client.utils.menuOption(
          `Utilities`,
          this.client.emoji.helpMenu.utility,
          `Useful bot utility commands`,
          `utility-help`
        );
        const menuOptionInfo = this.client.utils.menuOption(
          `Information`,
          this.client.emoji.helpMenu.info,
          `Bot info & stats commands`,
          `info-help`
        );
        const menuOptionAll = this.client.utils.menuOption(
          `All Commands`,
          this.client.emoji.helpMenu.allCommands,
          `List every command`,
          `all-help`
        );

        const menus = [
          menuOptionHome,
          menuOptionMusic,
          menuOptionFilters,
          menuOptionUtility,
          menuOptionInfo,
          menuOptionAll,
        ];
        const menu = this.client.utils.menu(`📑 Choose a category`, `help-menu`, menus);
        const menuRow = this.client.utils.actionRow([menu]);

        // Link buttons for extra flair
        const linkRow = this.client.utils.actionRow([
          this.client.utils.button("link", `Support`, 5, null, this.client.config.server, this.client.emoji.support),
          this.client.utils.button("link", `Invite`, 5, null, inviteUrl, this.client.emoji.invite),
          this.client.utils.button("link", `Vote`, 5, null, this.client.config.voteUrl, this.client.emoji.vote),
        ]);

        const msg = await message.reply({
          embeds: [em],
          components: [menuRow, linkRow],
        }).catch(() => null);

        if (!msg) return;

        const collector = msg.createMessageComponentCollector({
          filter: (b: any) => {
            if (b.user.id === message.author.id) return true;
            b.reply({
              content: `${this.client.emoji.cross} You are not the help command requester`,
              ephemeral: true,
            }).catch(() => {});
            return false;
          },
          time: 100000 * 7,
        });

        collector.on("collect", async (interaction: any) => {
          if (!interaction.isStringSelectMenu()) return;
          const value = interaction.values[0];

          if (value === `music-help`) {
            return interaction.update({ embeds: [makeCatEmbed("music", "Music Commands", this.client.emoji.helpMenu.music)] }).catch(() => {});
          } else if (value === `filter-help`) {
            return interaction.update({ embeds: [makeCatEmbed("filters", "Filter Commands", this.client.emoji.helpMenu.filters)] }).catch(() => {});
          } else if (value === `utility-help`) {
            return interaction.update({ embeds: [makeCatEmbed("utility", "Utility Commands", this.client.emoji.helpMenu.utility)] }).catch(() => {});
          } else if (value === `info-help`) {
            return interaction.update({ embeds: [makeCatEmbed("info", "Informative Commands", this.client.emoji.helpMenu.info)] }).catch(() => {});
          } else if (value === `all-help`) {
            return interaction.update({ embeds: [makeAllEmbed()] }).catch(() => {});
          } else if (value === `help-home`) {
            return interaction.update({ embeds: [em] }).catch(() => {});
          }
        });

        collector.on("end", async () => {
          try {
            menu.setDisabled(true);
            linkRow.components.forEach((b: any) => b.setDisabled(true));
            await msg.edit({ components: [menuRow, linkRow] }).catch(() => {});
          } catch (_) {}
        });

        return;
      }

      // ───────────────────────── ARGS PROVIDED → CATEGORY OR COMMAND ─────────────────────────
      const query = args[0].toLowerCase();

      // Category shortcuts (also reachable via the menu values)
      const catMap: { [k: string]: { cat: string; title: string; emoji: string } } = {
        music: { cat: "music", title: "Music Commands", emoji: this.client.emoji.helpMenu.music },
        filters: { cat: "filters", title: "Filter Commands", emoji: this.client.emoji.helpMenu.filters },
        filter: { cat: "filters", title: "Filter Commands", emoji: this.client.emoji.helpMenu.filters },
        info: { cat: "info", title: "Informative Commands", emoji: this.client.emoji.helpMenu.info },
        information: { cat: "info", title: "Informative Commands", emoji: this.client.emoji.helpMenu.info },
        utility: { cat: "utility", title: "Utility Commands", emoji: this.client.emoji.helpMenu.utility },
        dev: { cat: "dev", title: "Owner Commands", emoji: "👑" },
        owner: { cat: "dev", title: "Owner Commands", emoji: "👑" },
        all: { cat: "all", title: "All Commands", emoji: this.client.emoji.helpMenu.allCommands },
      };

      if (catMap[query]) {
        const { cat, title, emoji } = catMap[query];
        const embed = cat === "all" ? makeAllEmbed() : makeCatEmbed(cat, title, emoji);
        return message.reply({ embeds: [embed] });
      }

      // Specific command lookup by name or alias
      const cmd =
        this.client.commands.messages.get(query) ||
        this.client.commands.messages.find(
          (c: any) => c.aliases && c.aliases.includes(query)
        );

      if (!cmd) {
        return message.reply({
          embeds: [
            this.client.utils
              .errorEmbed()
              .setDescription(
                `${this.client.emoji.cross} There is no such command \`${args.join(" ")}\``
              ),
          ],
        });
      }

      const cmdEmbed = this.client.utils
        .premiumEmbed(message.guildId)
        .setAuthor({
          name: `${this.client.user.username}`,
          iconURL: this.client.user.displayAvatarURL(),
        })
        .setTitle(`${this.client.emoji.info} Command: ${cmd.name}`)
        .setThumbnail(guildIcon)
        .setDescription(
          "```xml\n<> = Required Argument  •  [] = Optional Argument\n```"
        )
        .addFields([
          {
            name: `${this.client.emoji.tick} Description`,
            value: `${cmd.desc ? cmd.desc : "No description provided."}`,
          },
          {
            name: `${this.client.emoji.queue} Usage`,
            value: `\`${prefix}${cmd.usage ? cmd.usage : cmd.name}\``,
            inline: true,
          },
          {
            name: `📂 Category`,
            value: `\`${cmd.cat ? cmd.cat : "uncategorized"}\``,
            inline: true,
          },
          {
            name: `🔗 Aliases`,
            value: `${
              cmd.aliases && cmd.aliases.length
                ? cmd.aliases.map((x: any) => `\`${x}\``).sort().join(", ")
                : "No aliases"
            }`,
            inline: true,
          },
        ])
        .setFooter({
          text: `Requested By: ${message.author.tag} • Made with 🔥 By Raahi Development`,
          iconURL: message.author.displayAvatarURL({ dynamic: true }),
        });

      return message.reply({ embeds: [cmdEmbed] });
    };
  }
}
