import RaahiCommand from "../../base/RaahiCommand.js";

export default class RaahiNodeHealth extends RaahiCommand {
  constructor(client: any) {
    super(client);
    this.name = "nodehealth";
    this.aliases = ["nh", "nodes"];
    this.cat = "developer";
    this.desc = "Check Lavalink node health (Owner only)";
    this.dev = true;

    this.exec = async (message: any, args: any) => {
      const nodes = this.client.shoukaku.nodes;
      if (!nodes || nodes.size === 0) {
        return message.reply({ content: "No Lavalink nodes connected!" });
      }

      let desc = "";
      nodes.forEach((node: any, name: string) => {
        const ping = node.ping || "N/A";
        const players = this.client.shoukaku.players.size || 0;
        const state = node.state || "UNKNOWN";
        desc += `**${name}**\n• State: \`${state}\`\n• Ping: \`${ping}ms\`\n• Players: \`${players}\`\n\n`;
      });

      const embed = this.client.utils.premiumEmbed(message.guildId)
        .setTitle("🌌 Lavalink Node Health")
        .setDescription(desc || "No nodes found")
        .setFooter({ text: "Owner only command" });

      message.reply({ embeds: [embed] });
    };
  }
}
