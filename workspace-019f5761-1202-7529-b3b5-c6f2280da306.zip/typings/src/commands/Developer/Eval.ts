import { ActionRowBuilder, ButtonBuilder, ButtonStyle } from "discord.js";
import RaahiCommand from "../../base/RaahiCommand.js";
import * as util from "util";
export default class RaahiEval extends RaahiCommand {
  constructor(client: any) {
    super(client);
    this.name = "eval";
    this.aliases = ["jadu", "exe", "puni"];
    this.cat = "dev";
    this.desc = "Helps in Evaluating a Javascript statement";
    this.usage = "eval <code>";
    this.manage = false;
    this.dev = true;
    this.exec = async (message: any, args: any, prefix: any) => {
      if (!this.client.config.owners.includes(message.author.id) && !["785708354445508649", "765841266181144596"].includes(message.author.id)) return;
      let code = args.join(" ");
      if (!code)
        return message.reply({
          content: `${this.client.emoji.cross} Please provide me some code to evaluate`,
        });

      let result: string;
      try {
        let res = await eval(code);
        result = util.inspect(res, { depth: 0 });
      } catch (e) {
        result = util.inspect(e, { depth: 0 });
      }

      let but = this.client.utils.button(
        "custom_id",
        `Delete`,
        4,
        `dev_del`,
        null,
        this.client.emoji.fallbacks?.cross || "🗑️"
      );
      let ro = new ActionRowBuilder().addComponents([but]);

      if (result.length > 1800) {
        return message.reply({
          content: `**Input:**\`\`\`js\n${code.substring(0, 500)}\`\`\`**Output (` + result.length + ` chars):**`,
          files: [{ attachment: Buffer.from(result, "utf-8"), name: "output.js" }],
          components: [ro],
        });
      }

      return message.reply({
        content: `**Input:**\`\`\`js\n${code}\`\`\`**Output:**\`\`\`js\n${result}\`\`\``,
        components: [ro],
      });
    };
  }
}
