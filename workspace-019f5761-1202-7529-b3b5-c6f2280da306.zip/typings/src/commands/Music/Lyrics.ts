import RaahiCommand from "../../base/RaahiCommand.js";
import { createCanvas } from "@napi-rs/canvas";
import axios from "axios";

export default class QuantumLyrics extends RaahiCommand {
  constructor(client: any) {
    super(client);
    this.name = "lyrics";
    this.aliases = ["ly"];
    this.cat = "music";
    this.desc = "Shows visual lyrics for the current song! 🎤✨";
    this.usage = "lyrics [query]";
    this.dispatcher = true;
    this.playing = true;
    
    this.exec = async (message: any, args: any, prefix: any, dispatcher: any) => {
      const query = args.join(" ") || dispatcher.current.info.title;
      
      const resMsg = await message.reply({ content: `🔍 **Searching the Multiverse for lyrics...**` });

      try {
        // Using a public free API for demonstration
        const url = `https://some-random-api.com/lyrics?title=${encodeURIComponent(query)}`;
        const res = await axios.get(url, { timeout: 5000 }).catch(() => null);

        if (!res?.data?.lyrics) {
            const fallbackEmbed = this.client.utils.premiumEmbed(message.guildId)
                .setTitle("🎤 Quantum Lyrics")
                .setDescription(`💅 **Bestie!** I couldn't find the exact visual lyrics for **${query}**.\n\n*Try a more specific song title!*`)
                .setFooter({ text: "Vibing in the loading trenches..." });
            return resMsg.edit({ content: null, embeds: [fallbackEmbed] });
        }

        const lyrics = res.data.lyrics;
        const lines = lyrics.split("\n").filter((l: string) => l.trim() !== "").slice(0, 10);

        const canvas = createCanvas(800, 600);
        const ctx = canvas.getContext("2d");

        // UI Design
        ctx.fillStyle = "#111214";
        ctx.fillRect(0, 0, 800, 600);

        // Header
        ctx.fillStyle = "#FF85A2";
        ctx.font = "bold 35px sans-serif";
        ctx.fillText("🎤 QUANTUM LYRICS", 40, 60);

        ctx.fillStyle = "#ffffff";
        ctx.font = "bold 25px sans-serif";
        ctx.fillText(res.data.title.substring(0, 40), 40, 100);

        // Render Lines
        lines.forEach((line: string, i: number) => {
            const y = 180 + (i * 45);
            ctx.fillStyle = i === 0 ? "#FF85A2" : "#9ba3a4"; // Highlight first line
            ctx.font = i === 0 ? "bold 24px sans-serif" : "20px sans-serif";
            ctx.fillText(line.substring(0, 60), 60, y);
        });

        ctx.fillStyle = "#9ba3a4";
        ctx.font = "italic 16px sans-serif";
        ctx.fillText("Serving main character vocals only 💅", 40, 560);

        const attachment = this.client.utils.attachment(canvas.toBuffer("image/png"));
        await resMsg.delete().catch(() => {});
        return message.reply({ files: [attachment] });

      } catch (e) {
          console.error(e);
          return resMsg.edit({ content: "💀 Something went wrong while fetching the vibes!" });
      }
    };
  }
}
