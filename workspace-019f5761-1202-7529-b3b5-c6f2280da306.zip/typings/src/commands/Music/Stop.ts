import RaahiCommand from "../../base/RaahiCommand.js";

export default class Stop extends RaahiCommand {
  constructor(client: any) {
    super(client);
    this.name = "stop";
    this.aliases = ["stop"];
    this.cat = "music";
    this.vc = true;
    this.desc = "Stops the player and resetts the queue";
    this.samevc = true;
    this.dispatcher = true;
    this.playing = true;
    this.exec = async (
      message: any,
      args: any,
      prefix: any,
      dispatcher: any
    ) => {
      await dispatcher.destroy();

      return message.reply({
        embeds: [
          this.client.utils
            .premiumEmbed(message.guildId || message.guild?.id)
            .setDescription(
              `⏹️ *Slay bestie! Successfully **stopped** the player and cleared the queue! Hop back anytime when u wanna vibe again!* ✨🌸`
            ),
        ],
      });
    };
  }
}
