import RaahiCommand from "../../base/RaahiCommand.js";

export default class Remove extends RaahiCommand {
  constructor(client: any) {
    super(client);
    this.name = "remove";
    this.aliases = ["rem"];
    this.cat = "music";
    this.vc = true;
    this.samevc = true;
    this.desc = "Removes a track from the queue using position";
    this.dispatcher = true;
    this.playing = true;
    this.exec = async (
      message: any,
      args: any,
      prefix: any,
      dispatcher: any
    ) => {
      if (!args[0] || isNaN(args[0]))
        return message.reply({
        embeds: [
          this.client.utils
            .premiumEmbed(message.guildId || message.guild?.id)
            .setDescription(
              `🗑️ *Slay! Successfully **removed** that track from our aesthetic queue!* ✨🌸`
            ),
        ],
      });
    };
  }
}
