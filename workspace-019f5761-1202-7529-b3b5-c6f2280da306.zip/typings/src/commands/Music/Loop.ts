import RaahiCommand from "../../base/RaahiCommand.js";

export default class Loop extends RaahiCommand {
  constructor(client: any) {
    super(client);
    this.name = "loop";
    this.aliases = [];
    this.desc = "Sets the loop mode of the player";
    this.usage = "loop <off/track/queue>";
    this.cat = "music";
    this.dev = false;
    this.vc = true;
    this.samevc = true;
    this.dispatcher = true;
    this.playing = true;
    this.vote = false;
    this.exec = async (
      message: any,
      args: any,
      prefix: any,
      dispatcher: any
    ) => {
      if (!args[0]) {
        return message.reply({
          embeds: [
            this.client.utils
              .premiumEmbed(message.guild.id)
              .setTitle(`🌸 ✨ • Loop Subcommands • ✨ 🌸`)
              .setDescription(
                `\`${prefix}loop off\`\n• *Disables loop mode so the queue flows naturally bestie!* ✨\n\n` +
                `\`${prefix}loop track\`\n• *Loops the current track on endless repeat! Slay!* 🔁💖\n\n` +
                `\`${prefix}loop queue\`\n• *Loops our entire aesthetic queue endlessly!* 🫧🌸`
              )
              .setTimestamp(),
          ],
        }).catch(() => {});
      }

      const mode = args[0].toLowerCase();
      if (mode === "off" || mode === "disable") {
        dispatcher.repeat = "off";
        return message.reply({
          embeds: [
            this.client.utils
              .premiumEmbed(message.guildId || message.guild?.id)
              .setDescription(
                `🔁 *Slay bestie! Looping mode disabled (**Off**)! We letting the queue flow naturally!* ✨🌸`
              ),
          ],
        }).catch(() => {});
      }

      if (mode === "track" || mode === "song" || mode === "current" || mode === "one") {
        dispatcher.repeat = "one";
        return message.reply({
          embeds: [
            this.client.utils
              .premiumEmbed(message.guildId || message.guild?.id)
              .setDescription(
                `🔁 *Bussin! Looping mode set to **Track**! We repeating this absolute banger on endless repeat!* ✨🌸`
              ),
          ],
        }).catch(() => {});
      }

      if (mode === "all" || mode === "queue") {
        dispatcher.repeat = "all";
        return message.reply({
          embeds: [
            this.client.utils
              .premiumEmbed(message.guildId || message.guild?.id)
              .setDescription(
                `🔁 *Slay bestie! Looping mode set to **Queue**! We cycling through all our immaculate vibes on endless repeat!* ✨🌸`
              ),
          ],
        }).catch(() => {});
      }

      return message.reply({
        embeds: [
          this.client.utils
            .premiumEmbed(message.guild.id)
            .setTitle(`🌸 ✨ • Loop Subcommands • ✨ 🌸`)
            .setDescription(
              `\`${prefix}loop off\`\n• *Disables loop mode so the queue flows naturally bestie!* ✨\n\n` +
              `\`${prefix}loop track\`\n• *Loops the current track on endless repeat! Slay!* 🔁💖\n\n` +
              `\`${prefix}loop queue\`\n• *Loops our entire aesthetic queue endlessly!* 🫧🌸`
            )
            .setTimestamp(),
        ],
      }).catch(() => {});
    };
  }
}
