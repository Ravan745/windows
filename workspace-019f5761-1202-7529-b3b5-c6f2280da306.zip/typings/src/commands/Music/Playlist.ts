import RaahiCommand from "../../base/RaahiCommand.js";
import { createPlaylist, addToPlaylist, getPlaylist, listPlaylists, deletePlaylist } from "../../api/db/playlists.js";

export default class RaahiPlaylist extends RaahiCommand {
  constructor(client: any) {
    super(client);
    this.name = "playlist";
    this.aliases = ["pl"];
    this.cat = "music";
    this.desc = "💅 Manage your personal playlists bestie! Create, add, play & slay 🔥";
    this.usage = "playlist <create/add/play/list/delete> <name>";
    this.vc = false;
    this.samevc = false;

    this.exec = async (message: any, args: any, prefix: any) => {
      const sub = args[0]?.toLowerCase();
      const name = args.slice(1).join(" ");

      if (!sub) {
        return message.reply({
          embeds: [this.client.utils.premiumEmbed(message.guildId).setDescription(
            `**Playlist Commands:**\n` +
            `\`${prefix}playlist create <name>\` — Create a new playlist\n` +
            `\`${prefix}playlist add <name>\` — Add current song to playlist\n` +
            `\`${prefix}playlist play <name>\` — Play a playlist\n` +
            `\`${prefix}playlist list\` — See your playlists\n` +
            `\`${prefix}playlist delete <name>\` — Delete a playlist`
          )]
        });
      }

      if (sub === "create") {
        if (!name) return message.reply({ content: "💅 Bestie give me a playlist name!" });
        const success = createPlaylist(message.author.id, name);
        if (success) {
          return message.reply({ content: `✨ Playlist **${name}** created! Go add some bangers bestie 🔥` });
        } else {
          return message.reply({ content: `💀 Playlist **${name}** already exists queen!` });
        }
      }

      if (sub === "add") {
        const dispatcher = this.client.api.get(message.guildId);
        if (!dispatcher?.current) return message.reply({ content: "🥺 Nothing is playing bestie!" });

        if (!name) return message.reply({ content: "Give me the playlist name!" });
        const added = addToPlaylist(message.author.id, name, dispatcher.current);
        if (added) {
          return message.reply({ content: `💖 Added **${dispatcher.current.info.title}** to **${name}**!` });
        } else {
          return message.reply({ content: `Playlist **${name}** not found!` });
        }
      }

      if (sub === "play") {
        if (!name) return message.reply({ content: "Which playlist bestie?" });
        const playlist = getPlaylist(message.author.id, name);
        if (!playlist || !playlist.tracks.length) {
          return message.reply({ content: `Playlist **${name}** is empty or doesn't exist!` });
        }

        let node = this.client.shoukaku.getNode();
        const dispatcher = await this.client.api.handle(
          message.guild, message.member, message.channel, node, playlist.tracks[0]
        );

        for (let i = 1; i < playlist.tracks.length; i++) {
          dispatcher.queue.push(playlist.tracks[i]);
        }
        dispatcher.play();

        return message.reply({
          embeds: [this.client.utils.premiumEmbed(message.guildId).setDescription(
            `🎵 Playing playlist **${name}** with **${playlist.tracks.length}** tracks! Slay bestie 🔥`
          )]
        });
      }

      if (sub === "list") {
        const lists = listPlaylists(message.author.id);
        if (!lists.length) return message.reply({ content: "You have no playlists yet bestie!" });

        const embed = this.client.utils.premiumEmbed(message.guildId)
          .setTitle("💅 Your Playlists")
          .setDescription(lists.map(p => `• **${p.name}** — ${p.count} songs`).join("\n"));
        return message.reply({ embeds: [embed] });
      }

      if (sub === "delete") {
        if (!name) return message.reply({ content: "Which playlist to delete?" });
        const deleted = deletePlaylist(message.author.id, name);
        if (deleted) {
          return message.reply({ content: `🗑️ Deleted playlist **${name}**!` });
        } else {
          return message.reply({ content: `Playlist **${name}** not found!` });
        }
      }
    };
  }
}
