import RaahiCommand from "../../base/RaahiCommand.js";

export default class Shuffle extends RaahiCommand {
  constructor(client: any) {
    super(client);
    this.name = "shuffle";
    this.aliases = [];
    this.cat = "music";
    this.vc = true;
    this.desc = "Shuffles the queue of the player";
    this.samevc = true;
    this.dispatcher = true;
    this.playing = true;
    this.exec = async (
      message: any,
      args: any,
      prefix: any,
      dispatcher: any
    ) => {
      if (!dispatcher.queue.length)
        return message.reply({
        embeds: [
          this.client.utils
            .premiumEmbed(message.guildId || message.guild?.id)
            .setDescription(
              `🔀 *Slay bestie! Successfully **shuffled** the queue! Let"s see what immaculate tunes drop next!* ✨🌸`
            ),
        ],
      });
    };
  }
}
