import RaahiCommand from "../../base/RaahiCommand.js";

export default class Previous extends RaahiCommand {
  constructor(client: any) {
    super(client);
    this.name = "previous";
    this.aliases = ["prev"];
    this.cat = "music";
    this.vc = true;
    this.samevc = true;
    this.vote = false;
    this.desc = "Plays the previous track of the queue and skips the current";
    this.usage = "previous";
    this.dispatcher = true;
    this.premium = {
      guild: false,
      user: false,
    };
    this.playing = true;
    this.exec = async (
      message: any,
      args: any,
      prefix: any,
      dispatcher: any
    ) => {
      if (dispatcher.previous === null || !dispatcher.previous) {
        return message.reply({
          embeds: [
            this.client.utils
              .premiumEmbed(message.guild.id)
              .setDescription(
                `${this.client.emoji.cross} Aww bestie! There is no previous song in history right now! ✨🌸`
              ),
          ],
        }).catch(() => {});
      } else {
        dispatcher.queue.unshift(dispatcher.previous);
        dispatcher.player.stopTrack();
        return message.reply({
          embeds: [
            this.client.utils
              .premiumEmbed(message.guild.id)
              .setDescription(
                `⏮️ *Bussin! Skipped back and started playing our **previous track**! Slay bestie!* ✨🌸`
              ),
          ],
        }).catch(() => {});
      }
    };
  }
}
