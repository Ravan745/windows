import RaahiCommand from "../../base/RaahiCommand.js";

export default class Disconnect extends RaahiCommand {
  constructor(client: any) {
    super(client);
    this.name = "disconnect";
    this.desc = "Disconnects the bot from a voice channel";
    this.aliases = ["leave"];
    this.cat = "music";
    this.manage = false;
    this.dev = false;
    this.vc = true;
    this.samevc = true;
    this.dispatcher = true;
    this.exec = async (
      message: any,
      args: any,
      prefix: any,
      dispatcher: any
    ) => {
      dispatcher.destroy();

      return message.reply({
        embeds: [
          this.client.utils
            .premiumEmbed(message.guildId || message.guild?.id)
            .setDescription(
              `🥺 *Aww bestie, hopping out of the voice channel and resting my wings! Call me back whenever u wanna vibe again!* ✨💖`
            ),
        ],
      });
    };
  }
}
