import RaahiCommand from "../../base/RaahiCommand.js";

export default class RaahiSurprise extends RaahiCommand {
  constructor(client: any) {
    super(client);
    this.name = "surprise";
    this.aliases = ["random", "surpriseme"];
    this.cat = "music";
    this.desc = "💅 Let the bot surprise you with a banger!";

    this.exec = async (message: any) => {
      const vibes = ["lofi chill", "pop hits", "bollywood bangers", "nightcore", "anime op", "indie vibes", "rap god", "sad songs", "party hits"];
      const randomVibe = vibes[Math.floor(Math.random() * vibes.length)];

      let node = this.client.shoukaku.getNode();
      let result = await this.client.utils.resolve(node, `ytsearch:${randomVibe}`).catch(() => null);
      if (!result?.tracks?.length) return message.reply({ content: "Couldn't find anything bestie!" });

      const track = result.tracks[Math.floor(Math.random() * result.tracks.length)];
      track.info.requester = message.author;
      const tr = this.client.utils.track(track);

      const dispatcher = await this.client.api.handle(message.guild, message.member, message.channel, node, tr);
      dispatcher?.play();

      return message.reply({
        embeds: [this.client.utils.cuteMusicCard(tr, message.author)]
      });
    };
  }
}
