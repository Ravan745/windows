import RaahiCommand from "../../base/RaahiCommand.js";

export default class ClearQueue extends RaahiCommand {
  constructor(client: any) {
    super(client);
    this.name = "clearqueue";
    this.aliases = ["clear"];
    this.desc = "Cleares the queue of the player";
    this.usage = "clearqueue";
    this.cat = "music";
    this.vc = true;
    this.samevc = true;
    this.vote = false;
    this.manage = false;
    this.dev = false;
    this.dispatcher = true;
    this.exec = async (
      message: any,
      args: any,
      prefix: any,
      dispatcher: any
    ) => {
      if (!dispatcher.queue.length)
        return message.reply({
          embeds: [
            this.client.utils
              .premiumEmbed(message.guildId || message.guild?.id)
              .setDescription(
                `🫧 *Slay! Successfully cleared every single upcoming song from our aesthetic queue! Starting fresh bestie!* 🗑️💖`
              ),
          ],
        });
      else {
        await dispatcher.queue.splice(0);
        return message.reply({
          embeds: [
            this.client.utils
              .premiumEmbed(message.guildId || message.guild?.id)
              .setDescription(
                `🫧 *Slay! Successfully cleared every single upcoming song from our aesthetic queue! Starting fresh bestie!* 🗑️💖`
              ),
          ],
        });
      }
    };
  }
}
