import ms from "ms";
import RaahiCommand from "../../base/RaahiCommand.js";

export default class Seek extends RaahiCommand {
  constructor(client: any) {
    super(client);
    this.name = "seek";
    this.aliases = [];
    this.cat = "music";
    this.vc = true;
    this.samevc = true;
    this.desc = "Seeks the player to the provided timestamp";
    this.usage = "seek <time>\nexample: seek 1m40s";
    this.dispatcher = true;
    this.playing = true;
    this.exec = async (
      message: any,
      args: any,
      prefix: any,
      dispatcher: any
    ) => {
      if (!args[0]) {
        return message.reply({
          embeds: [
            this.client.utils
              .premiumEmbed(message.guild.id)
              .setDescription(`🌸 *Slay bestie! Provide a timestamp to seek to!* \n**Example:** \`${prefix}seek 1m40s\` ✨`),
          ],
        }).catch(() => {});
      }
      let seek = ms(`${args.slice(0).join(" ")}`);
      if (isNaN(seek) || seek > dispatcher.current.info.length) {
        return message.reply({
          embeds: [
            this.client.utils
              .premiumEmbed(message.guild.id)
              .setDescription(
                `${this.client.emoji.cross} Aww bestie! Please provide a valid timestamp within the song duration! ✨🌸`
              )
              .setTitle(`Invalid Timestamp`),
          ],
        }).catch(() => {});
      }
      if (seek < 0) seek = 0;

      await dispatcher.player.seekTo(seek);

      return message.reply({
        embeds: [
          this.client.utils
            .premiumEmbed(message.guildId || message.guild?.id)
            .setDescription(
              `⏩ *Slay bestie! Fast-forwarded to timestamp: \`${args[0]}\`! Serving immaculate timing!* ✨🌸`
            ),
        ],
      }).catch(() => {});
    };
  }
}
