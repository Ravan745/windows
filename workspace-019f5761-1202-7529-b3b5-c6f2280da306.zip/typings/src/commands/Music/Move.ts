import RaahiCommand from "../../base/RaahiCommand.js";

export default class Move extends RaahiCommand {
  constructor(client: any) {
    super(client);
    this.name = "move";
    this.aliases = ["skipto", "jump"];
    this.cat = "music";
    this.vc = true;
    this.samevc = true;
    this.desc = "Jumps to the particular track in the queue";
    this.usage = "move <number>";
    this.dispatcher = true;
    this.premium = {
      user: false,
      guild: false,
    };
    this.playing = true;
    this.exec = async (message: any, args: any, prefix: any, dispatcher: any) => {
      if (!args[0]) {
        return message.reply({
          embeds: [
            this.client.utils
              .premiumEmbed(message.guildId || message.guild?.id)
              .setDescription(`${this.client.emoji.cross} Bestie, please provide a song index from our aesthetic queue to jump to! ✨🌸`),
          ],
        }).catch(() => {});
      }

      let pos = Number(args[0]);
      if (isNaN(pos) || pos > dispatcher.queue.length || pos < 1) {
        return message.reply({
          embeds: [
            this.client.utils
              .premiumEmbed(message.guildId || message.guild?.id)
              .setDescription(`${this.client.emoji.cross} Bestie, please provide a valid song number between **1** and **${dispatcher.queue.length}**! ✨🌸`),
          ],
        }).catch(() => {});
      }

      if (pos === 1) {
        dispatcher.player.stopTrack();
      } else {
        dispatcher.queue.splice(0, pos - 1);
        dispatcher.player.stopTrack();
      }

      return message.reply({
        embeds: [
          this.client.utils
            .premiumEmbed(message.guildId || message.guild?.id)
            .setDescription(`⏩ *Slay bestie! Successfully jumped/moved to track **#${pos}** in the queue! Serving clean vibes!* ✨🌸`),
        ],
      }).catch(() => {});
    };
  }
}
