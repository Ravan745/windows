import RaahiCommand from "../../base/RaahiCommand.js";

export default class RaahiVolume extends RaahiCommand {
  constructor(client: any) {
    super(client);
    this.name = "volume";
    this.aliases = ["vol"];
    this.cat = "music";
    this.dev = false;
    this.manage = false;
    this.desc = "Controls the volume of the player";
    this.usage = "volume <number>";
    this.vc = true;
    this.samevc = true;
    this.premium = {
      guild: false,
      user: false,
    };
    this.exec = async (message: any, args: any, prefix: any) => {
      const dispatcher = this.client.api.get(message.guildId || message.guild?.id);
      if (!dispatcher || !dispatcher.player) {
        return message.reply({
          embeds: [
            this.client.utils
              .errorEmbed()
              .setDescription(
                `${this.client.emoji.cross} Aww bestie! There is no active music player right now! ✨🌸`
              ),
          ],
        }).catch(() => {});
      }
      if (!args[0]) {
        let currentVol = Math.round((dispatcher.player.volume ?? (dispatcher.player.filters?.volume ? dispatcher.player.filters.volume * 100 : 100)));
        return message.reply({
          embeds: [
            this.client.utils
              .premiumEmbed(message.guildId || message.guild?.id)
              .setDescription(
                `🔊 *Current volume is set to **${currentVol}%** bestie! Serving clean vibes!* ✨🌸`
              ),
          ],
        }).catch(() => {});
      }
      let num = Number(args[0]);
      if (isNaN(num) || num < 1 || num > 200) {
        return message.reply({
          embeds: [
            this.client.utils
              .premiumEmbed(message.guildId || message.guild?.id)
              .setDescription(
                `${this.client.emoji.cross} Bestie, volume must be between **1 and 200%**! ✨🌸`
              )
              .setTitle(`Invalid Volume`),
          ],
        }).catch(() => {});
      }
      await dispatcher.player.setGlobalVolume(num);

      return message.reply({
        embeds: [
          this.client.utils
            .premiumEmbed(message.guildId || message.guild?.id)
            .setDescription(
              `🔊 *Slay bestie! Volume adjusted to **${num}%**! Immaculate vibes only!* ✨🌸`
            ),
        ],
      }).catch(() => {});
    };
  }
}
