import RaahiCommand from "../../base/RaahiCommand.js";

export default class Pause extends RaahiCommand {
  constructor(client: any) {
    super(client);
    this.name = "pause";
    this.aliases = [];
    this.desc = "Pauses the current track";
    this.cat = "music";
    this.vc = true;
    this.samevc = true;
    this.dev = false;
    this.manage = false;
    this.dispatcher = true;
    this.playing = true;
    this.exec = async (
      message: any,
      args: any,
      prefix: any,
      dispatcher: any
    ) => {
      if (dispatcher.player.paused)
        return message.reply({
        embeds: [
          this.client.utils
            .premiumEmbed(message.guildId || message.guild?.id)
            .setDescription(
              `⏸️ *Slay! Player successfully **paused**! Take a little tea break bestie!* ✨🌸`
            ),
        ],
      });

      await dispatcher.player.setPaused(true);
      return message.reply({
        embeds: [
          this.client.utils
            .premiumEmbed(message.guildId)
            .setDescription(
              `${this.client.emoji.tick} Successfully **Paused** the Player!`
            )
            .setTitle(`Paused`),
        ],
      });
    };
  }
}
