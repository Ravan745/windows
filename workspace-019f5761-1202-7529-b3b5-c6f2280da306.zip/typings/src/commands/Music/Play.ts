import axios from "axios";
import RaahiDispatcher from "../../api/Dispatcher.js";
import RaahiCommand from "../../base/RaahiCommand.js";

export default class RaahiPlay extends RaahiCommand {
  constructor(client: any) {
    super(client);
    this.name = "play";
    this.aliases = ["p"];
    this.cat = "music";
    this.desc = "💅 Gen Z AI music bot. Just drop the song name bestie and I'll cook up the most bussin' track for you 🔥✨";
    this.usage = "play <query/url>";
    this.dev = false;
    this.manage = false;
    this.premium = {
      guild: false,
      user: false,
    };
    this.vc = true;
    this.samevc = true;

    this.exec = async (message: any, args: any, prefix: any) => {
      if (!args[0])
        return message.reply({
          embeds: [
            this.client.utils
              .premiumEmbed(message.guildId)
              .setDescription(`\`${prefix}play <search query or url>\``)
              .setTitle(`🌸 Play Syntax • Futuristic Edition ✨`),
          ],
        }).catch(() => {});

      const query = args.join(" ").trim();

      // ✨ MULTI-STAGE LOADING UX
      const searchingMsg = await message.reply({
        embeds: [this.client.utils.premiumEmbed(message.guildId)
          .setDescription(`🔍 **Scanning the multiverse for vibes...** ✨`)
          .setFooter({ text: "Quantum AI Engine Initializing..." })]
      }).catch(() => null);

      setTimeout(async () => {
         if (searchingMsg) await searchingMsg.edit({
            embeds: [this.client.utils.premiumEmbed(message.guildId)
              .setDescription(`✨ **Quantum AI is cooking your track rn...** 🔥`)
              .setFooter({ text: "Slaying the processing trenches..." })]
         }).catch(() => {});
      }, 1500);

      // Futuristic smart source detection
      let node = this.client.shoukaku.getNode();
      let track: any = null;
      let dispatcher: any = null;

      try {
        // 1. Handle direct URLs
        if (this.client.utils.checkUrl(query)) {
          if (query.match(this.client.spotify.spotifyPattern)) {
            await this.client.spotify.requestToken().catch(() => {});
            let spotiNode = this.client.spotify.nodes?.get("Raahi");
            if (spotiNode) {
              let result = await spotiNode.load(query).catch(() => null);
              if (result?.loadType === `PLAYLIST_LOADED` && result.tracks?.length) {
                dispatcher = await this._ensureDispatcher(message);
                let spotifyTracks = result.tracks.map((t: any) => {
                  t.info.requester = message.author;
                  return this.client.utils.track(t);
                });
                spotifyTracks.forEach((x: any) => dispatcher.queue.push(x));
                if (!dispatcher.current) dispatcher.play();

                if (searchingMsg) await searchingMsg.delete().catch(() => {});
                return message.reply({
                  embeds: [
                    this.client.utils.premiumEmbed(message.guildId).setDescription(
                      `${this.client.emoji.queue} **✨ SLAY BESTIE!** Added **${result.tracks.length}** tracks to the queue 🔥 This playlist is about to eat! 💅🎧`
                    ),
                  ],
                }).catch(() => {});
              } else if (result?.tracks?.[0]) {
                let t = result.tracks[0];
                t.info.requester = message.author;
                track = this.client.utils.track(t);
              }
            }
          }

          if (!track) {
            let result = await this.client.utils.resolve(node, query).catch(() => null);
            if (result?.tracks?.length) {
              if (result.loadType === `PLAYLIST_LOADED`) {
                dispatcher = await this._ensureDispatcher(message);
                let tracks = result.tracks.map((t: any) => {
                  t.info.requester = message.author;
                  return this.client.utils.track(t);
                });
                tracks.forEach((x: any) => dispatcher.queue.push(x));
                if (!dispatcher.current) dispatcher.play();

                if (searchingMsg) await searchingMsg.delete().catch(() => {});
                return message.reply({
                  embeds: [
                    this.client.utils.premiumEmbed(message.guildId).setDescription(
                      `${this.client.emoji.queue} **✨ PERIODT!** Added **${result.tracks.length}** tracks to the queue 🔥 This is gonna be so good bestie! 💅🎵`
                    ),
                  ],
                }).catch(() => {});
              } else {
                let t = result.tracks[0];
                t.info.requester = message.author;
                track = this.client.utils.track(t);
              }
            }
          }
        }

        // 2. Futuristic AI Smart Search (multi-engine)
        if (!track) {
          // Spotify first
          try {
            let spotifyRes = await this.client.kazagumo.search(query, {
              engine: `spotify`,
              requester: message.author,
            }).catch(() => null);
            if (spotifyRes?.tracks?.length) {
              track = spotifyRes.tracks[0];
              try {
                await this.client.spotify.requestToken().catch(() => {});
                let spoti = this.client.spotify.nodes?.get("Raahi");
                if (spoti && track.uri) {
                  let res = await spoti.load(track.uri).catch(() => null);
                  if (res?.tracks?.[0]) track = this.client.utils.track(res.tracks[0]);
                }
              } catch (_) {}
            }
          } catch (_) {}

          // YouTube fallback
          if (!track) {
            let ytRes = await this.client.utils.resolve(node, `ytsearch:${query}`).catch(() => null);
            if (ytRes?.tracks?.length) {
              track = this.client.utils.track(ytRes.tracks[0]);
              track.info.requester = message.author;
            }
          }

          // Deezer fallback
          if (!track) {
            try {
              let deezerRes = await this.client.kazagumo.search(query, {
                engine: `deezer`,
                requester: message.author,
              }).catch(() => null);
              if (deezerRes?.tracks?.length) {
                track = deezerRes.tracks[0];
              }
            } catch (_) {}
          }

          // SoundCloud final fallback
          if (!track) {
            let scRes = await this.client.utils.resolve(node, `scsearch:${query}`).catch(() => null);
            if (scRes?.tracks?.length) {
              track = this.client.utils.track(scRes.tracks[0]);
              track.info.requester = message.author;
            }
          }
        }

        if (!track) {
          if (searchingMsg) await searchingMsg.delete().catch(() => {});
          return message.reply({
            embeds: [
              this.client.utils.premiumEmbed(message.guildId).setDescription(
                `${this.client.emoji.cross} **Bestie...** 💀 No matches found for **\`${query}\`**! Try another banger that actually slaps! 🥺✨`
              ),
            ],
          }).catch(() => {});
        }

        // Handle track
        track.info.requester = message.author;
        let tr = this.client.utils.track(track);

        dispatcher = await this.client.api.handle(
          message.guild,
          message.member,
          message.channel,
          node,
          tr
        );
        dispatcher?.play();

        // Delete searching message
        if (searchingMsg) await searchingMsg.delete().catch(() => {});

        // ✨ Send adorable music card
        const musicCard = this.client.utils.cuteMusicCard(tr, message.author);

        const row1 = this.client.utils.actionRow([
          this.client.utils.button(`custom_id`, null, 2, `raahi_shuffle`, null, "🔀"),
          this.client.utils.button(`custom_id`, null, 2, `raahi_previous`, null, "⏮️"),
          this.client.utils.button(`custom_id`, null, 3, `raahi_pause`, null, this.client.emoji.raahiNew.pause),
          this.client.utils.button(`custom_id`, null, 2, `raahi_skip`, null, "⏭️"),
          this.client.utils.button(`custom_id`, null, 2, `raahi_loop`, null, "🔁"),
        ]);

        const row2 = this.client.utils.actionRow([
          this.client.utils.button(`custom_id`, null, 2, `raahi_autoplay`, null, "♾️"),
          this.client.utils.button(`custom_id`, null, 2, `raahi_volLow`, null, "🔉"),
          this.client.utils.button(`custom_id`, null, 4, `raahi_stop`, null, "⏹️"),
          this.client.utils.button(`custom_id`, null, 2, `raahi_volHigh`, null, "🔊"),
          this.client.utils.button(`custom_id`, null, 2, `raahi_queue`, null, "📜"),
        ]);

        return message.reply({
          embeds: [musicCard],
          components: [row1, row2],
        }).catch(() => {});

      } catch (err: any) {
        console.error(`[Futuristic Play Error]`, err);
        if (searchingMsg) await searchingMsg.delete().catch(() => {});
        return message.reply({
          embeds: [
            this.client.utils.premiumEmbed(message.guildId).setDescription(
              `${this.client.emoji.cross} **Bestie...** 💀 Something went wrong. Try again queen! 🥺✨`
            ),
          ],
        }).catch(() => {});
      }
    };

    // Futuristic private helper
    this._ensureDispatcher = async (message: any) => {
      let dispatcher = this.client.api.get(message.guildId);
      if (dispatcher) return dispatcher;

      const botMember = this.client.utils.getBotMember(message.guild);
      if (
        !botMember?.permissionsIn(message.member.voice.channel)
          .has(["Connect", "Speak"])
      ) {
        throw new Error("Missing permissions");
      }

      let node = this.client.shoukaku.getNode();
      let player = await this.client.shoukaku.joinVoiceChannel({
        guildId: message.guildId,
        channelId: message.member.voice.channel.id,
        shardId: message.guild.shardId,
        deaf: true,
      });
      dispatcher = new RaahiDispatcher(this.client, message.guild, message.channel, player);
      this.client.api.set(message.guild.id, dispatcher);
      return dispatcher;
    };
  }

  private async _ensureDispatcher(message: any) {
    let dispatcher = this.client.api.get(message.guildId);
    if (dispatcher) return dispatcher;

    const botMember = this.client.utils.getBotMember(message.guild);
    if (
      !botMember?.permissionsIn(message.member.voice.channel)
        .has(["Connect", "Speak"])
    ) {
      throw new Error("Missing permissions");
    }

    let node = this.client.shoukaku.getNode();
    let player = await this.client.shoukaku.joinVoiceChannel({
      guildId: message.guildId,
      channelId: message.member.voice.channel.id,
      shardId: message.guild.shardId,
      deaf: true,
    });
    dispatcher = new RaahiDispatcher(this.client, message.guild, message.channel, player);
    this.client.api.set(message.guild.id, dispatcher);
    return dispatcher;
  }
}
