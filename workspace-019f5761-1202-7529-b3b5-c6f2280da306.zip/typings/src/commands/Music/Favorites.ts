import RaahiCommand from "../../base/RaahiCommand.js";
import { addFavorite, getFavorites, removeFavorite, clearFavorites } from "../../api/db/favorites.js";

export default class RaahiFavorites extends RaahiCommand {
  constructor(client: any) {
    super(client);
    this.name = "favorites";
    this.aliases = ["fav", "favs"];
    this.cat = "music";
    this.desc = "💖 Manage your favorite songs!";

    this.exec = async (message: any, args: any) => {
      const sub = args[0]?.toLowerCase();

      if (!sub || sub === "list") {
        const favs = getFavorites(message.author.id);
        if (!favs.length) return message.reply({ content: "You have no favorites yet bestie!" });

        const embed = this.client.utils.premiumEmbed(message.guildId)
          .setTitle("💖 Your Favorites")
          .setDescription(favs.slice(0, 10).map((t: any, i: number) => 
            `**${i+1}.** ${t.info.title.substring(0, 50)}`).join("\n"));

        return message.reply({ embeds: [embed] });
      }

      if (sub === "add") {
        const dispatcher = this.client.api.get(message.guildId);
        if (!dispatcher?.current) return message.reply({ content: "Nothing is playing!" });

        const added = addFavorite(message.author.id, dispatcher.current);
        return message.reply({ 
          content: added ? "💖 Added to favorites!" : "Already in your favorites!" 
        });
      }

      if (sub === "remove") {
        const identifier = args[1];
        if (!identifier) return message.reply({ content: "Give me the song identifier!" });
        removeFavorite(message.author.id, identifier);
        return message.reply({ content: "Removed from favorites!" });
      }

      if (sub === "play") {
        const favs = getFavorites(message.author.id);
        if (!favs.length) return message.reply({ content: "No favorites!" });

        let node = this.client.shoukaku.getNode();
        const dispatcher = await this.client.api.handle(message.guild, message.member, message.channel, node, favs[0]);
        
        favs.slice(1).forEach((t: any) => dispatcher.queue.push(t));
        dispatcher.play();

        return message.reply({ content: `🎵 Playing your **${favs.length}** favorites!` });
      }

      if (sub === "clear") {
        clearFavorites(message.author.id);
        return message.reply({ content: "All favorites cleared!" });
      }
    };
  }
}
