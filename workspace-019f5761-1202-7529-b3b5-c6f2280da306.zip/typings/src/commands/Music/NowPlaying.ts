import RaahiCommand from "../../base/RaahiCommand.js";
import RaahiPlayer from "../../base/RaahiPlayer.js";

export default class NowPlaying extends RaahiCommand {
  constructor(client: any) {
    super(client);
    this.name = "nowplaying";
    this.aliases = ["np"];
    this.cat = "music";
    this.vote = true;
    this.vc = true;
    this.samevc = true;
    this.dispatcher = true;
    this.playing = true;
    this.exec = async (
      message: any,
      args: any,
      prefix: any,
      dispatcher: any
    ) => {
      if (!dispatcher) return message.reply({
        embeds: [
          this.client.utils.premiumEmbed(message.guildId).setDescription(`${this.client.emoji.cross} I am not Playing anything currently`)
        ]
      })
      let current = dispatcher.current;
      let player = dispatcher.player;
      await message.channel.sendTyping();

      let vani = new RaahiPlayer(this.client);
      vani.build(current, player).then((result) => {
        let em = this.client.utils.premiumEmbed(message.guildId);
        let png = this.client.utils.attachment(result);

        em.setTitle(`✨ 🌸 • Now Playing • 🌸 ✨`)
          .setDescription(`**[${current.info.title.substring(0, 45)}](${this.client.config.voteUrl})**\n\n**• Requester:** ${current.info.requester?.tag || "Raahi User"}\n**• Author:** ${current.info.author}\n**• Duration:** \`${this.client.utils.humanize(player.position).split(".")[0]} / ${this.client.utils.humanize(current.info.length)}\``)
          .setImage("attachment://RaahiNowPlaying.png")
          .setFooter({
            text: `Made with 💖 by Raahi • Your Futuristic Music Companion ✨`,
            iconURL: this.client.user?.displayAvatarURL?.() || "",
          });

        return message.reply({
          embeds: [em],
          files: [png],
        });
      });
    };
  }
}
