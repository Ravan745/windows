import RaahiCommand from "../../base/RaahiCommand.js";

export default class Vibrato extends RaahiCommand {
  constructor(client: any) {
    super(client);
    this.name = "vibrato";
    this.aliases = [];
    this.cat = "filters";
    this.vc = true;
    this.samevc = true;
    this.vote = true;
    this.desc = "Toggles Vibrato filter to the player";
    this.usage = "vibrato";
    this.dispatcher = true;
    this.playing = true;
    this.exec = async (
      message: any,
      args: any,
      prefix: any,
      dispatcher: any
    ) => {
      let status = await dispatcher.setFilter("vibrato");

      return message.reply({
        embeds: [
          this.client.utils
            .premiumEmbed(message.guildId || message.guild?.id)
            .setDescription(
              status
                ? `${this.client.emoji.tick} Successfully **Applied Vibrato** filter to the player`
                : `${this.client.emoji.tick} Successfully **Disabled Vibrato** filter from the player`
            ),
        ],
      });
    };
  }
}
