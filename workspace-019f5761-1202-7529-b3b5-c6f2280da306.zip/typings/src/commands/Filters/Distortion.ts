import RaahiCommand from "../../base/RaahiCommand.js";

export default class Distortion extends RaahiCommand {
  constructor(client: any) {
    super(client);
    this.name = "distortion";
    this.aliases = [];
    this.cat = "filters";
    this.manage = false;
    this.vote = true;
    this.desc = "Toggles distortion filter to the player";
    this.usage = "distortion";
    this.vc = true;
    this.samevc = true;
    this.dispatcher = true;
    this.playing = true;
    this.exec = async (
      message: any,
      args: any,
      prefix: any,
      dispatcher: any
    ) => {
      let status = await dispatcher.setFilter("distortion");

      return message.reply({
        embeds: [
          this.client.utils
            .premiumEmbed(message.guildId || message.guild?.id)
            .setDescription(
              status
                ? `${this.client.emoji.tick} Successfully **Applied Distortion** filter to the player`
                : `${this.client.emoji.tick} Successfully **Disabled Distortion** filter from the player`
            ),
        ],
      });
    };
  }
}
