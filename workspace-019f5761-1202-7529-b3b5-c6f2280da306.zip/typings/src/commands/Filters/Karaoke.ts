import RaahiCommand from "../../base/RaahiCommand.js";

export default class Karaoke extends RaahiCommand {
  constructor(client: any) {
    super(client);
    this.name = "karaoke";
    this.aliases = [];
    this.cat = "filters";
    this.manage = false;
    this.vote = true;
    this.usage = "karaoke";
    this.desc = "Toggles karaoke filter to the player";
    this.vc = true;
    this.samevc = true;
    this.dispatcher = true;
    this.playing = true;
    this.exec = async (
      message: any,
      args: any,
      prefix: any,
      dispatcher: any
    ) => {
      let status = await dispatcher.setFilter("karaoke");

      return message.reply({
        embeds: [
          this.client.utils
            .premiumEmbed(message.guildId || message.guild?.id)
            .setDescription(
              status
                ? `${this.client.emoji.tick} Successfully **Applied Karaoke** filter to the player`
                : `${this.client.emoji.tick} Successfully **Disabled Karaoke** filter from the player`
            ),
        ],
      });
    };
  }
}
