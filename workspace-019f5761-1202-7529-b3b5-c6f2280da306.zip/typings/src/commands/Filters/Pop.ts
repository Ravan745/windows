import RaahiCommand from "../../base/RaahiCommand.js";

export default class Pop extends RaahiCommand {
  constructor(client: any) {
    super(client);
    this.name = "pop";
    this.aliases = [];
    this.cat = "filters";
    this.manage = false;
    this.vote = true;
    this.vc = true;
    this.desc = "Toggles pop filter to the player";
    this.usage = "pop";
    this.samevc = true;
    this.dispatcher = true;
    this.playing = true;
    this.exec = async (
      message: any,
      args: any,
      prefix: any,
      dispatcher: any
    ) => {
      let status = await dispatcher.setFilter("pop");

      return message.reply({
        embeds: [
          this.client.utils
            .premiumEmbed(message.guildId || message.guild?.id)
            .setDescription(
              status
                ? `${this.client.emoji.tick} Successfully **Applied Pop** filter to the player`
                : `${this.client.emoji.tick} Successfully **Disabled Pop** filter from the player`
            ),
        ],
      });
    };
  }
}
