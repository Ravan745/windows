import RaahiCommand from "../../base/RaahiCommand.js";

export default class NightCore extends RaahiCommand {
  constructor(client: any) {
    super(client);
    this.name = "nightcore";
    this.aliases = [];
    this.cat = "filters";
    this.manage = false;
    this.vote = true;
    this.desc = "Toggles nightcore filter to the player";
    this.usage = "nightcore";
    this.vc = true;
    this.samevc = true;
    this.dispatcher = true;
    this.playing = true;
    this.exec = async (
      message: any,
      args: any,
      prefix: any,
      dispatcher: any
    ) => {
      let status = await dispatcher.setFilter("nightcore");

      return message.reply({
        embeds: [
          this.client.utils
            .premiumEmbed(message.guildId || message.guild?.id)
            .setDescription(
              status
                ? `${this.client.emoji.tick} Successfully **Applied Nightcore** filter to the player`
                : `${this.client.emoji.tick} Successfully **Disabled Nightcore** filter from the player`
            ),
        ],
      });
    };
  }
}
