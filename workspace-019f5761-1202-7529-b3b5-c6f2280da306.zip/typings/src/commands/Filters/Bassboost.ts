import RaahiCommand from "../../base/RaahiCommand.js";

export default class Bassboost extends RaahiCommand {
  constructor(client: any) {
    super(client);
    this.name = "bassboost";
    this.aliases = [];
    this.cat = "filters";
    this.usage = "bassboost";
    this.desc = "Toggles BassBoost filter to the player";
    this.manage = false;
    this.vote = true;
    this.vc = true;
    this.samevc = true;
    this.dispatcher = true;
    this.playing = true;
    this.exec = async (
      message: any,
      args: any,
      prefix: any,
      dispatcher: any
    ) => {
      let status = await dispatcher.setFilter("bassboost");

      return message.reply({
        embeds: [
          this.client.utils
            .premiumEmbed(message.guildId)
            .setDescription(
              status
                ? `${this.client.emoji.tick} Successfully **Applied Bassboost** filter to the player`
                : `${this.client.emoji.tick} Successfully **Disabled Bassboost** filter from the player`
            ),
        ],
      });
    };
  }
}
