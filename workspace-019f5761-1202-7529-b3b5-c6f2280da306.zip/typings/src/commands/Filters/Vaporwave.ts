import RaahiCommand from "../../base/RaahiCommand.js";

export default class Vaporwave extends RaahiCommand {
  constructor(client: any) {
    super(client);
    this.name = "vaporwave";
    this.aliases = [];
    this.cat = "filters";
    this.dev = false;
    this.vc = true;
    this.desc = "Toggles Vaporwave filter to the player";
    this.usage = "vaporwave";
    this.vote = true;
    this.samevc = true;
    this.dispatcher = true;
    this.playing = true;
    this.exec = async (
      message: any,
      args: any,
      prefix: any,
      dispatcher: any
    ) => {
      let status = await dispatcher.setFilter("vaporwave");

      return message.reply({
        embeds: [
          this.client.utils
            .premiumEmbed(message.guildId || message.guild?.id)
            .setDescription(
              status
                ? `${this.client.emoji.tick} Successfully **Applied Vaporwave** filter to the player`
                : `${this.client.emoji.tick} Successfully **Disabled Vaporwave** filter from the player`
            ),
        ],
      });
    };
  }
}
