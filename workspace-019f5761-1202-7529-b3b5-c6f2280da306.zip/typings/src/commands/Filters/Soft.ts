import RaahiCommand from "../../base/RaahiCommand.js";

export default class Soft extends RaahiCommand {
  constructor(client: any) {
    super(client);
    this.name = "soft";
    this.aliases = [];
    this.cat = "filters";
    this.manage = false;
    this.vote = true;
    this.vc = true;
    this.desc = "Toggles soft filter to the player";
    this.usage = "soft";
    this.samevc = true;
    this.dispatcher = true;
    this.playing = true;
    this.exec = async (
      message: any,
      args: any,
      prefix: any,
      dispatcher: any
    ) => {
      let status = await dispatcher.setFilter("soft");

      return message.reply({
        embeds: [
          this.client.utils
            .premiumEmbed(message.guildId || message.guild?.id)
            .setDescription(
              status
                ? `${this.client.emoji.tick} Successfully **Applied Soft** filter to the player`
                : `${this.client.emoji.tick} Successfully **Disabled Soft** filter from the player`
            ),
        ],
      });
    };
  }
}
