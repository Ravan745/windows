import RaahiCommand from "../../base/RaahiCommand.js";

export default class Daycore extends RaahiCommand {
  constructor(client: any) {
    super(client);
    this.name = "daycore";
    this.aliases = [];
    this.cat = "filters";
    this.manage = false;
    this.desc = "Toggles Daycore filter to the player";
    this.usage = "daycore";
    this.vote = true;
    this.vc = true;
    this.samevc = true;
    this.dispatcher = true;
    this.playing = true;
    this.exec = async (
      message: any,
      args: any,
      prefix: any,
      dispatcher: any
    ) => {
      let status = await dispatcher.setFilter("daycore");

      return message.reply({
        embeds: [
          this.client.utils
            .premiumEmbed(message.guildId || message.guild?.id)
            .setDescription(
              status
                ? `${this.client.emoji.tick} Successfully **Applied Daycore** filter to the player`
                : `${this.client.emoji.tick} Successfully **Disabled Daycore** filter from the player`
            ),
        ],
      });
    };
  }
}
