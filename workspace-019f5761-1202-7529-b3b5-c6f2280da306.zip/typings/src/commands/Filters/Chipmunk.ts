import RaahiCommand from "../../base/RaahiCommand.js";

export default class Chipmunk extends RaahiCommand {
  constructor(client: any) {
    super(client);
    this.name = "chipmunk";
    this.aliases = [];
    this.cat = "filters";
    this.manage = false;
    this.vote = true;
    this.vc = true;
    this.desc = "Toggles Chipmunk filter to the player";
    this.usage = "chipmunk";
    this.samevc = true;
    this.dispatcher = true;
    this.playing = true;
    this.exec = async (
      message: any,
      args: any,
      prefix: any,
      dispatcher: any
    ) => {
      let status = await dispatcher.setFilter("chipmunk");

      return message.reply({
        embeds: [
          this.client.utils
            .premiumEmbed(message.guildId || message.guild?.id)
            .setDescription(
              status
                ? `${this.client.emoji.tick} Successfully **Applied Chipmunk** filter to the player`
                : `${this.client.emoji.tick} Successfully **Disabled Chipmunk** filter from the player`
            ),
        ],
      });
    };
  }
}
