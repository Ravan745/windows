import RaahiCommand from "../../base/RaahiCommand.js";

export default class Enhance extends RaahiCommand {
  constructor(client: any) {
    super(client);
    this.name = "enhance";
    this.aliases = ["enh"];
    this.cat = "filters";
    this.usage = "enhance";
    this.desc = "Toggles audio enhancement filter for crystal clear sound";
    this.manage = false;
    this.vote = true;
    this.vc = true;
    this.samevc = true;
    this.dispatcher = true;
    this.playing = true;
    this.exec = async (
      message: any,
      args: any,
      prefix: any,
      dispatcher: any
    ) => {
      let status = await dispatcher.setFilter("enhance");

      return message.reply({
        embeds: [
          this.client.utils
            .premiumEmbed(message.guildId || message.guild?.id)
            .setDescription(
              status
                ? `${this.client.emoji.tick} Successfully **Applied Enhance** filter to the player ✨🌸`
                : `${this.client.emoji.tick} Successfully **Disabled Enhance** filter from the player ✨🌸`
            ),
        ],
      });
    };
  }
}
