import RaahiCommand from "../../base/RaahiCommand.js";

export default class Tremolo extends RaahiCommand {
  constructor(client: any) {
    super(client);
    this.name = "tremolo";
    this.aliases = [];
    this.cat = "filters";
    this.manage = false;
    this.vc = false;
    this.desc = "Togglss tremolo filter to the player";
    this.usage = "tremolo";
    this.samevc = false;
    this.vote = true;
    this.dispatcher = true;
    this.playing = true;
    this.exec = async (
      message: any,
      args: any,
      prefix: any,
      dispatcher: any
    ) => {
      let status = await dispatcher.setFilter("tremolo");

      return message.reply({
        embeds: [
          this.client.utils
            .premiumEmbed(message.guildId || message.guild?.id)
            .setDescription(
              status
                ? `${this.client.emoji.tick} Successfully **Applied Tremolo** filter to the player`
                : `${this.client.emoji.tick} Successfully **Disabled Tremolo** filter from the player`
            ),
        ],
      });
    };
  }
}
