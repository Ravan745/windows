import RaahiCommand from "../../base/RaahiCommand.js";

export default class EightD extends RaahiCommand {
  constructor(client: any) {
    super(client);
    this.name = "8d";
    this.aliases = ["eightD", "eight-d"];
    this.cat = "filters";
    this.dev = false;
    this.desc = "Toggles 8D filter for the player";
    this.usage = "8d";
    this.vote = true;
    this.premium = {
      guild: false,
      user: false,
    };
    this.vc = true;
    this.samevc = true;
    this.dispatcher = true;
    this.playing = true;
    this.exec = async (
      message: any,
      args: any,
      prefix: any,
      dispatcher: any
    ) => {
      let status = await dispatcher.setFilter("8d");

      return message.reply({
        embeds: [
          this.client.utils
            .premiumEmbed(message.guild.id)
            .setDescription(
              status
                ? `${this.client.emoji.tick} Successfully **Applied 8D filter** to the Player`
                : `${this.client.emoji.tick} Successfully **Disabled 8D filter** from the Player`
            ),
        ],
      });
    };
  }
}
