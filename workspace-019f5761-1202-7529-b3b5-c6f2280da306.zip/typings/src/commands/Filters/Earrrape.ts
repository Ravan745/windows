import RaahiCommand from "../../base/RaahiCommand.js";

export default class Earrape extends RaahiCommand {
  constructor(client: any) {
    super(client);
    this.name = "earrape";
    this.aliases = [];
    this.cat = "filters";
    this.manage = false;
    this.vote = true;
    this.desc = "Toggles earrape filter to the player";
    this.usage = "earrape";
    this.vc = true;
    this.samevc = true;
    this.dispatcher = true;
    this.playing = true;
    this.exec = async (
      message: any,
      args: any,
      prefix: any,
      dispatcher: any
    ) => {
      let status = await dispatcher.setFilter("earrape");

      return message.reply({
        embeds: [
          this.client.utils
            .premiumEmbed(message.guildId || message.guild?.id)
            .setDescription(
              status
                ? `${this.client.emoji.tick} Successfully **Applied Earrape** filter to the player`
                : `${this.client.emoji.tick} Successfully **Disabled Earrape** filter from the player`
            ),
        ],
      });
    };
  }
}
