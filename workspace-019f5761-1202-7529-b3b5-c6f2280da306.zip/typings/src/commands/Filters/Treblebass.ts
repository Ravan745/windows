import RaahiCommand from "../../base/RaahiCommand.js";

export default class Treblebass extends RaahiCommand {
  constructor(client: any) {
    super(client);
    this.name = "treblebass";
    this.aliases = [];
    this.desc = "Toggles treblebass filter to the player";
    this.usage = "treblebass";
    this.cat = "filters";
    this.manage = false;
    this.premium = {
      guild: false,
      user: false,
    };
    this.vote = true;
    this.vc = true;
    this.samevc = true;
    this.exec = async (
      message: any,
      args: any,
      prefix: any,
      dispatcher: any
    ) => {
      let status = await dispatcher.setFilter("treblebass");

      return message.reply({
        embeds: [
          this.client.utils
            .premiumEmbed(message.guildId || message.guild?.id)
            .setDescription(
              status
                ? `${this.client.emoji.tick} Successfully **Applied Treblebass** filter to the player`
                : `${this.client.emoji.tick} Successfully **Disabled Treblebass** filter from the player`
            ),
        ],
      });
    };
  }
}
