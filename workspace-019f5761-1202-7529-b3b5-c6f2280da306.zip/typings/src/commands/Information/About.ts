import RaahiCommand from "../../base/RaahiCommand.js";

export default class About extends RaahiCommand {
  constructor(client: any) {
    super(client);
    this.name = "about";
    this.desc = "Provides you with the information of the bot";
    this.usage = "about";
    this.aliases = ["botinfo", "bi"];
    this.cat = "info";
    this.exec = async (message: any, args: any, prefix: any) => {
      let em = this.client.utils
        .premiumEmbed(message.guildId)
        .setTitle(`About ${this.client.user.username}`)
        .setAuthor({
          name: `${this.client.user.username} Information`,
          iconURL: this.client.user.displayAvatarURL(),
        })
        .setThumbnail(this.client.user.displayAvatarURL())
        .setDescription(
          `**${this.client.user.username}** is a high-quality, feature-rich Discord music bot built with **TypeScript**, **discord.js v14**, and **Shoukaku / Lavalink 4** for crystal-clear audio.\n\n` +
          `We support multi-platform music streaming across **YouTube**, **Spotify**, **Deezer**, and **SoundCloud** with custom audio filters, 24/7 playback, custom embed styling, and interactive buttons.`
        )
        .addFields([
          {
            name: `👨‍💻 Developers & Creators`,
            value: `**• [Punit](https://discord.com/users/765841266181144596)** (Lead Developer)\n**• [Rihan.ly](https://discord.com/users/785708354445508649)** (Co-Developer)`,
            inline: true,
          },
          {
            name: `👑 Team & Owners`,
            value: `**• [Sumit](https://discord.com/users/259176352748404736)**\n**• [Rohit](https://discord.com/users/735003878424313908)**`,
            inline: true,
          },
          {
            name: `⚡ Performance & Tech Stack`,
            value: `**• Framework:** discord.js v14\n**• Audio Engine:** Shoukaku / Lavalink v4\n**• Memory Usage:** \`${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)} MB\`\n**• Ping:** \`${this.client.ws.ping}ms\``,
            inline: false,
          },
        ])
        .setFooter({
          text: `Thank you for choosing ${this.client.user.username}!`,
          iconURL: message.author.displayAvatarURL({ dynamic: true }),
        })
        .setTimestamp();

      let b1 = this.client.utils.button(
        "link",
        "Invite Me",
        null,
        null,
        `https://discord.com/api/oauth2/authorize?client_id=${this.client.user.id}&permissions=8&scope=bot%20applications.commands`,
        this.client.emoji.invite
      );
      let b2 = this.client.utils.button(
        "link",
        "Support Server",
        null,
        null,
        `${this.client.config.server}`,
        this.client.emoji.support
      );
      let b3 = this.client.utils.button(
        "link",
        "Vote Me",
        null,
        null,
        `${this.client.config.voteUrl}`,
        this.client.emoji.vote
      );

      return message.reply({
        embeds: [em],
        components: [this.client.utils.actionRow([b1, b2, b3])],
      });
    };
  }
}
