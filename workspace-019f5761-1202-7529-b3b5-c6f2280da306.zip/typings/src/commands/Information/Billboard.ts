import { getTopTracks } from "../../api/db/stats.js";
import RaahiCommand from "../../base/RaahiCommand.js";
import { createCanvas } from "@napi-rs/canvas";

export default class Billboard extends RaahiCommand {
  constructor(client: any) {
    super(client);
    this.name = "billboard";
    this.aliases = ["top", "halloffame"];
    this.cat = "information";
    this.desc = "Shows the top tracks played in this server or globally! 🏆✨";
    this.usage = "billboard [global]";
    
    this.exec = async (message: any, args: any) => {
      const isGlobal = args[0]?.toLowerCase() === "global";
      const topTracks = getTopTracks(isGlobal ? null : message.guildId);
      
      if (!topTracks.length) {
        return message.reply({ content: `💅 **Bestie!** ${isGlobal ? "The Multiverse" : "This server"} has no history yet. Start vibing! 🔥` });
      }

      const canvas = createCanvas(600, 500);
      const ctx = canvas.getContext("2d");

      // Background
      ctx.fillStyle = "#111214";
      ctx.fillRect(0, 0, 600, 500);

      // Header
      ctx.fillStyle = "#FF85A2";
      ctx.font = "bold 40px sans-serif";
      ctx.fillText(isGlobal ? "🌌 MULTIVERSE CHART" : "🏆 SERVER BILLBOARD", 40, 60);
      ctx.fillStyle = "#9ba3a4";
      ctx.font = "20px sans-serif";
      ctx.fillText(isGlobal ? "Top Bangers Across the Multiverse" : "This Week's Most Bussin' Tracks", 40, 90);

      // List tracks
      topTracks.forEach((track, i) => {
          const y = 150 + (i * 70);
          
          // Rank circle
          ctx.beginPath();
          ctx.arc(60, y, 25, 0, Math.PI * 2);
          ctx.fillStyle = i === 0 ? "#FFD700" : "#2a2b2f"; // Gold for #1
          ctx.fill();
          
          ctx.fillStyle = "#ffffff";
          ctx.font = "bold 24px sans-serif";
          ctx.textAlign = "center";
          ctx.fillText(`${i + 1}`, 60, y + 8);
          
          // Track Info
          ctx.textAlign = "left";
          ctx.font = "bold 22px sans-serif";
          const title = track.TITLE.length > 30 ? track.TITLE.substring(0, 27) + "..." : track.TITLE;
          ctx.fillText(title, 110, y);
          
          ctx.font = "18px sans-serif";
          ctx.fillStyle = "#9ba3a4";
          const author = (track.AUTHOR || "Unknown").length > 35 ? track.AUTHOR.substring(0, 32) + "..." : track.AUTHOR;
          ctx.fillText(author, 110, y + 25);
          
          // Plays
          ctx.fillStyle = "#FF85A2";
          ctx.font = "bold 18px sans-serif";
          ctx.textAlign = "right";
          ctx.fillText(`${track.PLAYS} PLAYS`, 560, y + 10);
      });

      const attachment = this.client.utils.attachment(canvas.toBuffer("image/png"));
      return message.reply({ files: [attachment] });
    };
  }
}
