/**
 * ═══════════════════════════════════════════════════════════════
 *                    AVON EMOJI CENTRAL HUB
 * ═══════════════════════════════════════════════════════════════
 * 
 * All emojis used across the bot are defined here.
 * Easy to manage and update!
 * 
 * Categories:
 * 1. Basic Emojis (tick, cross, queue, etc.)
 * 2. Search Emojis (YouTube, Spotify, Deezer, SoundCloud)
 * 3. Setup/Player Emojis (pause, skip, volume, etc.)
 * 4. Style-Specific Emojis (raahiNew, spotify, simple, special)
 * 5. Badge & Presence Emojis
 * 6. Help Menu Emojis
 * 7. Unicode Fallbacks (when custom emojis fail)
 */

export default class RaahiEmoji extends Object {
  [x: string]: any;

  constructor(client: any) {
    super();

    // ═══════════════════════════════════════════════════════════════
    // 1. BASIC EMOJIS
    // ═══════════════════════════════════════════════════════════════
    this.tick = "<:raahitick:1129741544694485024>";
    this.cross = "<:raahicross:1129741483998724206>";
    this.playing = "<a:nowplaying:1129817857727942738>";
    this.exclamation = "<:raahiexe:1129744498449207296> ";
    this.queue = "<:raahiquaie:1129744532074922014> ";
    this.info = "<:raahiinfo2:1129751345226850375> ";
    this.premium = "<a:premium_raahi:1064927294730272939>";
    this.invite = "<:T_RedInvite:1130724489911599125>";
    this.support = "<:Support:1130724620757127189>";
    this.vote = "<:vote_raahi:1064932747400982588>";

    // ═══════════════════════════════════════════════════════════════
    // 2. SEARCH SOURCE EMOJIS
    // ═══════════════════════════════════════════════════════════════
    this.defSearch = "<a:premium_raahi:1064927294730272939>";      // YouTube
    this.spotiSearch = "<a:spotify:1129816498853138502>";         // Spotify
    this.deezSearch = "<:Deezer_raahi:1065634451603861545>";       // Deezer
    this.soundSearch = "<:Soundcloud_raahi:1065634569262473277>";  // SoundCloud

    // ═══════════════════════════════════════════════════════════════
    // 3. SETUP / PLAYER CONTROLS
    // ═══════════════════════════════════════════════════════════════
    this.setup = {
      pause: "<:raahipause:1129738547176419348>",
      resume: "<:raahiplay:1129738549739147294>",
      skip: "<:raahislip:1129744547644190770>",
      previous: "<:raahiright:1129738558660423680>",
      shuffle: "<:raahisuffle:1129751417138196623>",
      stop: "<:raahistop:1129747306040791180>",
      loop: "<:raahirequest:1129747309094260837>",
      volLow: "<:raahivolminus:1129744510814011543>",
      volHigh: "<:raahivol:1129738595603857489>",
      fav: "<:raahifav:1129751420099375144>",
      autoplay: "<a:botautoplay:1105072801779568701>",
      filters: "<:raahifilter:1129751347869265920>",
      author: "<a:8accountsolid1:1094833733984604211>",
      nowPlaying: "<a:77pausesolid:1094833726753603735>",
      requester: "<a:19booksolid1:1094833798941786192>",
      duration: "<a:67clocksolid1:1094833814204846180>",
    };

    // ═══════════════════════════════════════════════════════════════
    // 4. STYLE-SPECIFIC EMOJIS
    // ═══════════════════════════════════════════════════════════════

    // Raahi New Style
    this.raahiNew = {
      emote: "<a:botplaying:1129819082343063664>",
      nowPlaying: "<a:botplaying:1129819082343063664>",
      requester: "<:raahirequest:1129747309094260837>",
      duration: "<:raahitime:1129747295726997545>",
      author: "<:author_raahi:1129990460128108554>",
      pause: "<:Pause:1129824564386467991>",
      resume: "<:resume:1129824021618380801>",
      skip: "<:forward10:986893749005217812>",
      previous: "<:Raahi_Previous:1137298056283430982>",
      stop: "<:stop:1129823823399751690>",
      fav: "",
    };

    // Spotify Style
    this.spotify = {
      emote: "<a:spotify:1129816498853138502>",
      filters: "<:filter:1100222067938435152>",
      nowPlaying: "<a:spotify:1129816498853138502>",
      requester: "<:raahirequest:1129747309094260837>",
      duration: "<:raahitime:1129747295726997545>",
      pause: "<:ss_pause:1099927332204073011>",
      author: "<:author_raahi:1066716583365447720>",
      resume: "<:resume:1099927448734408744>",
      stop: "<:ss_stop:1099927856651436082>",
      loop: "<:loop:1129823572991426651>",
      shuffle: "<:shuffle:1139766210213462066>",
      forward: "<:backward:1129823401175949322>",
      backward: "<:forward10:1129823372008759327>",
      volLow: "<:lower_vol:1139766602527690902>",
      volHigh: "<:higher_vol:1139766719917854751>",
      previous: "<:Raahi_Previous:1137298056283430982>",
      skip: "<:last:1139768093766336632>",
    };

    // Special Style
    this.special = {
      emote: "<a:premium_raahi:1064927294730272939>",
      nowPlaying: "<a:premium_raahi:1064927294730272939>",
      requester: "<:raahirequest:1129747309094260837>",
      duration: "<:raahitime:1129747295726997545>",
      pause: "<:ss_pause:1099927332204073011>",
      author: "<:author_raahi:1066716583365447720>",
      resume: "<:resume:1099927448734408744>",
      stop: "<:ss_stop:1099927856651436082>",
      loop: "<:loop:1129823572991426651>",
      shuffle: "<:shuffle:1139766210213462066>",
      forward: "<:backward:1129823401175949322>",
      backward: "<:forward10:1129823372008759327>",
      volLow: "<:lower_vol:1139766602527690902>",
      volHigh: "<:higher_vol:1139766719917854751>",
      previous: "<:Raahi_Previous:1137298056283430982>",
      skip: "<:last:1139768093766336632>",
    };

    // Simple Style
    this.simple = {
      emote: "<a:nowplaying:1129817857727942738>",
      nowPlaying: "<a:nowplaying:1129817857727942738>",
      requester: "<:raahirequest:1129747309094260837>",
      author: "<:author_raahi:1066716583365447720>",
      duration: "<:raahitime:1129747295726997545>",
      filters: "<:filter:1100222067938435152>",
      pause: "<:ss_pause:1099927332204073011>",
      resume: "<:resume:1099927448734408744>",
      stop: "<:stop:1129823823399751690>",
      skip: "<:skip:1099927755342233720>",
      loop: "<:loop:1129823572991426651>",
    };

    // No Buttons Style
    this.noButtons = {
      emote: "<a:botplaying:1129819082343063664>",
      nowPlaying: "<a:botplaying:1129819082343063664>",
      author: "<:author_raahi:1066716583365447720>",
      requester: "<:raahirequest:1129747309094260837>",
      duration: "<:raahitime:1129747295726997545>",
      filters: "<:filter:1100222067938435152>",
    };

    // Old Style
    this.oldStyle = {
      emote: "<a:nowplaying:1129817857727942738>",
      nowPlaying: "<a:nowplaying:1129817857727942738>",
      author: "<:author_raahi:1129990460128108554>",
      requester: "<:raahirequest:1129747309094260837>",
      duration: "<:raahitime:1129747295726997545>",
    };

    // ═══════════════════════════════════════════════════════════════
    // 5. BADGES & PRESENCE
    // ═══════════════════════════════════════════════════════════════
    this.presence = {
      online: "<:online:1123087833788330066>",
      idle: "<:idle:1123087869460885614>",
      dnd: "<:dnd:1123087852834664468>",
      offline: "<:Offline:1123088263503159327>",
    };

    this.badges = {
      named: "<:owner:1073672248885518597>",
      owner: "<:raahiowner:1129738528209780836>",
      dev: "<:raahidev:1129738531527458856>",
      admin: "<:raahiadmin:1129738535952449628>",
      codev: "<:raahicodev:1129738585713692682>",
      author: "<:author_raahi:1129990460128108554>",
      friend: "<:raahifriend:1129744517080301638>",
      vip: "<:raahivip:1129741519243460698>",
      premiumUser: "<:raahipremium:1129741537731948544>",
      mod: "<:raahimod:1129741496858447982>",
      staff: "<:raahistaff:1129741494157328486>",
      supporter: "<:raahisupporter:1129741524536672378>",
      user: "<:raahimembers:1129741529448185917>",
    };

    // ═══════════════════════════════════════════════════════════════
    // 6. HELP MENU EMOJIS
    // ═══════════════════════════════════════════════════════════════
    this.helpMenu = {
      music: "<:Raahi_Music:1130897739086045208>",
      home: "<:Raahi_Home:1131253449158307850>",
      filters: "<:Raahi_Filters:1130897583242485891>",
      info: "<:Raahi_Info:1130897649000783893>",
      utility: "<:Raahi_Utility:1130897694605459497>",
      allCommands: "<:Raahi_AllCommands:1130897613131108402>",
    };

    // ═══════════════════════════════════════════════════════════════
    // 7. UNICODE FALLBACKS (Used when custom emojis are unavailable)
    // ═══════════════════════════════════════════════════════════════
    this.fallbacks = {
      // Player Controls
      pause: "⏸️",
      resume: "▶️",
      skip: "⏭️",
      previous: "⏮️",
      stop: "⏹️",
      loop: "🔁",
      shuffle: "🔀",
      volLow: "🔉",
      volHigh: "🔊",
      forward: "⏩",
      backward: "⏪",
      fav: "❤️",
      autoplay: "♾️",
      reset: "♻️",
      filter: "🎵",

      // Status
      tick: "✅",
      cross: "❌",
      vote: "⭐",

      // General
      link: "🔗",
      info: "ℹ️",
      queue: "📜",
      home: "🏠",
      music: "🎶",
      utility: "🛠️",
      commands: "📋",

      // Sources
      spotify: "🟢",
      deezer: "🟣",
      soundcloud: "🟠",
      youtube: "▶️",
    };
  }

  /**
   * Get fallback emoji if custom emoji fails
   */
  public getFallback(idStr: string = "", nameStr: string = ""): string | undefined {
    const s = `${idStr} ${nameStr}`.toLowerCase();

    if (s.includes("pause") || s.includes("resume") || s.includes("play")) return this.fallbacks.pause;
    if (s.includes("skip") || s.includes("next") || s.includes("slip") || s.includes("last") || (s.includes("forward") && !idStr.toLowerCase().includes("forward"))) return this.fallbacks.skip;
    if (s.includes("prev") || s.includes("back") || s.includes("right")) return this.fallbacks.previous;
    if (s.includes("stop")) return this.fallbacks.stop;
    if (s.includes("loop") || s.includes("repeat") || s.includes("request")) return this.fallbacks.loop;
    if (s.includes("shuffle") || s.includes("suffle")) return this.fallbacks.shuffle;
    if (s.includes("vollow") || s.includes("volminus") || s.includes("lower")) return this.fallbacks.volLow;
    if (s.includes("volhigh") || s.includes("volplus") || s.includes("higher") || s.includes("vol")) return this.fallbacks.volHigh;
    if (s.includes("forward")) return this.fallbacks.forward;
    if (s.includes("backward")) return this.fallbacks.backward;
    if (s.includes("fav") || s.includes("heart")) return this.fallbacks.fav;
    if (s.includes("autoplay")) return this.fallbacks.autoplay;
    if (s.includes("reset")) return this.fallbacks.reset;
    if (s.includes("filter") || s.includes("8d") || s.includes("bassboost") || s.includes("nightcore") || s.includes("vibrato")) return this.fallbacks.filter;
    if (s.includes("tick") || s.includes("yes") || s.includes("confirm")) return this.fallbacks.tick;
    if (s.includes("cross") || s.includes("no") || s.includes("cancel") || s.includes("decline")) return this.fallbacks.cross;
    if (s.includes("vote")) return this.fallbacks.vote;
    if (s.includes("invite") || s.includes("support") || s.includes("link")) return this.fallbacks.link;
    if (s.includes("info")) return this.fallbacks.info;
    if (s.includes("queue")) return this.fallbacks.queue;
    if (s.includes("home")) return this.fallbacks.home;
    if (s.includes("music")) return this.fallbacks.music;
    if (s.includes("utility")) return this.fallbacks.utility;
    if (s.includes("allcommands") || s.includes("commands")) return this.fallbacks.commands;
    if (s.includes("spoti")) return this.fallbacks.spotify;
    if (s.includes("deez")) return this.fallbacks.deezer;
    if (s.includes("sound")) return this.fallbacks.soundcloud;
    if (s.includes("default") || s.includes("youtube")) return this.fallbacks.youtube;

    return undefined;
  }
}
