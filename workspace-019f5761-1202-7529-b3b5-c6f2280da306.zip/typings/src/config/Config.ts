export default class RaahiConfig extends Object {
  token: string;
  prefix: string;
  nodes: object[];
  spotiId: string;
  owners: string[];
  spotiSecret: string;
  spotiNodes: object[];
  webhooks: object;
  supportId: string;
  color: string;
  server: string;
  voteUrl: string;
  voteApi: string;
  setupBgLink: string;
  constructor() {
    super();
    this.token =
      "";
    this.prefix = "+";
    this.nodes = [
      {
        name: `Raahi`,
        url: `localhost:2333`,
        auth: `raahibot`,
        secure: false,
      },
    ];
    this.voteApi =
      "";
    this.webhooks = {
      guildCreate:
        "",
      guildDelete:
        "",
      Cmds: "",
    };
    this.server = "https://discord.gg/raahibot";
    this.spotiId = "";
    this.spotiSecret = "";
    this.owners = ["765841266181144596"];
    this.color = "#FF85A2";
    this.supportId = "";
    this.spotiNodes = [
      {
        id: `Raahi`,
        host: `localhost`,
        port: 2333,
        password: `raahibot`,
        secure: false,
      },
    ];
    this.voteUrl = "https://top.gg/bot/904317141866647592/vote";
    this.setupBgLink =
      "";
  }
}
