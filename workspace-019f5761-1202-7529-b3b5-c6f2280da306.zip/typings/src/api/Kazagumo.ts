import { Kazagumo, Plugins } from "kazagumo";
import { Connectors } from "shoukaku";
import Deezer from "kazagumo-deezer";
import Spotify from "kazagumo-spotify";

export default class RaahiKazagumo extends Kazagumo {
  constructor(client: any) {
    super(
      {
        defaultSearchEngine: "youtube",
        send: (guildId, payload) => {
          let guild = client.guilds.cache.get(guildId);
          if (guild) guild.shard.send(payload);
        },
        plugins: [
          new Spotify({
            clientId: client.config.spotiId,
            clientSecret: client.config.spotiSecret,
            playlistPageLimit: 5,
            searchLimit: 50,
            albumPageLimit: 5,
            searchMarket: "IN",
          }),
          new Deezer(),
          new Plugins.PlayerMoved(client),
        ],
      },
      new Connectors.DiscordJS(client),
      [], // Pass empty array initially to prevent early connection errors
      {
        resume: true,
        resumeTimeout: 60,
        moveOnDisconnect: true,
        reconnectTries: 10,
        reconnectInterval: 5,
        restTimeout: 60,
      }
    );

    // 1. Attach ALL Shoukaku Event Listeners BEFORE adding nodes
    this.shoukaku.on("ready", (name) => {
      client.logger.log(`🌌 Lavalink Node "${name}" connected via Raahi!`);
    });

    this.shoukaku.on("error", (name, error) => {
      // This catches the 'ERR_UNHANDLED_ERROR' by providing a listener
      client.logger.error(`Lavalink Node "${name}" encountered a connection error:`, error?.message || error);
    });

    this.shoukaku.on("close", (name, code, reason) => {
      client.logger.warn(`Lavalink Node "${name}" closed. Code: ${code}, Reason: ${reason}`);
    });

    this.shoukaku.on("disconnect", (name, count) => {
      client.logger.warn(`Lavalink Node "${name}" disconnected; ${count} players affected.`);
    });
    
    // Polyfill getNode for the bot's legacy code
    (this.shoukaku as any).getNode = () => {
        return this.shoukaku.options.nodeResolver(this.shoukaku.nodes);
    };

    // 2. Now manually add nodes from config
    // This ensures our 'error' listener is already active when Shoukaku starts connecting
    if (client.config.nodes && Array.isArray(client.config.nodes)) {
        for (const node of client.config.nodes) {
            this.shoukaku.addNode(node);
        }
    }
  }
}
