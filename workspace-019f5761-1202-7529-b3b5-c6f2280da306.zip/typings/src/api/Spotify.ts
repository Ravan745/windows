export default class RaahiSpotify {
  public spotifyPattern: RegExp;
  public nodes: Map<string, { load: (query: string) => Promise<any> }>;
  private client: any;

  constructor(client: any) {
    this.client = client;
    this.spotifyPattern = /^(https?:\/\/open\.spotify\.com\/(track|album|playlist)\/[\w-]+|spotify:(track|album|playlist):[\w-]+)/i;
    this.nodes = new Map([
      [
        "Raahi",
        {
          load: (query: string) => this.load(query),
        },
      ],
    ]);
  }

  public async requestToken() {
    // Kept for the old command flow. Kazagumo's Spotify plugin manages its own
    // token lifecycle, so commands can continue to call this safely.
    return true;
  }

  private async load(query: string) {
    try {
      const result = await this.client.kazagumo.search(query, {
        engine: "spotify",
      }).catch(() => null);

      if (!result) return { loadType: "LOAD_FAILED", tracks: [] };

      const tracks = (result?.tracks ?? []).map((track: any) => {
        if (typeof track?.getRaw === "function") return track.getRaw();
        if (track?.encoded) return { track: track.encoded, info: track.info };
        return track;
      });

      if (!tracks.length) return { loadType: "NO_MATCHES", tracks: [] };

      if (result.type === "PLAYLIST") {
        return {
          loadType: "PLAYLIST_LOADED",
          tracks,
          playlistInfo: { name: result.playlistName ?? "Spotify Playlist" },
        };
      }

      return {
        loadType: result.type === "TRACK" ? "TRACK_LOADED" : "SEARCH_RESULT",
        tracks,
      };
    } catch (e) {
      return { loadType: "LOAD_FAILED", tracks: [] };
    }
  }
}
