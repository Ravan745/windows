import { Collection } from "discord.js";
import { get247Set, getAutoplay } from "./db/settings.js";
import { incrementPlayCount } from "./db/stats.js";
import { times } from "lodash";
import { getDjChannel } from "./db/dj.js";
import { saveGuildQueue, clearGuildQueue } from "./db/queue.js";

export default class RaahiDispatcher {
  public client: any;
  public guild: any;
  public channel: any;
  public player: any;
  public repeat: string;
  public current: any;
  public stopped: boolean;
  public punit: boolean;
  public previous: any;
  public queue: any[];
  public filter: string = "none";
  public data: Collection<string, any>;
  public aiMode: boolean = true; // Futuristic AI Mode for auto-recommendations
  public smartQueue: boolean = true;

  constructor(client: any, guild: any, channel: any, player: any) {
    this.client = client;
    this.guild = guild;
    this.channel = channel;
    this.player = player;
    this.repeat = "off";
    this.queue = [];
    this.data = new Collection();
    this.current = null;
    this.previous = null;
    this.stopped = false;
    this.punit = false;
    this.aiMode = true;
    this.smartQueue = true;

    // Futuristic enhanced player event handlers
    this.player.on("start", async () => {
      if (this.repeat === "one") {
        if (this.punit) return;
        else this.punit = true;
      }
      if (this.repeat === "all" || this.repeat === "off") {
        this.punit = false;
      }

      if (this.client.utils.checkDjSetup(this.guild.id) === true) {
        this.updateDj(this.guild);
        this.updateQueue(this.guild, this.queue);
      }

      // God-Tier: Increment Server Billboard
      incrementPlayCount(this.guild.id, this.current.info.requester.id, this.current.info.title, this.current.info.author);

      // Generate Card & Buttons
      await this._sendPlayerCard();

      // Start Presence Loop
      this._startVibeLoop();
    });

    this.player.on("end", async (data: any) => {
      this._stopVibeLoop();
      if (data.reason === "replaced") return;
      if (this.client.utils.checkDjSetup(this.guild.id) === true) {
        this.updateQueue(this.guild, this.queue);
      }

      try {
        this.data.get("Raahi")?.delete();
      } catch (_) {}

      this.data.delete("Raahi");
      this.previous = this.current;
      this.current = null;

      // Save queue for persistence
      if (this.queue.length > 0 || this.previous) {
        saveGuildQueue(this.guild.id, {
          current: this.current,
          queue: this.queue,
          repeat: this.repeat
        });
      } else {
        clearGuildQueue(this.guild.id);
      }

      // Futuristic AI Auto-Recommendation System
      if (this.aiMode && getAutoplay(this.guild.id).SETTING === 1) {
        return this.futuristicAutoplay();
      } else if (getAutoplay(this.guild.id).SETTING === 1) {
        return this.autoplay();
      } else {
        this.play();
      }
    });

    this.player.on("closed", () => {
        this._stopVibeLoop();
        this.destroy();
    });

    let errorCount = 0;
    this.player.on("error", (err: any) => {
      console.error(`[Raahi Futuristic Player Error]`, err);
      this._stopVibeLoop();
      
      errorCount++;
      if (errorCount > 3) {
          console.warn(`[Raahi] Excessive errors in guild ${this.guild.id}. Stopping playback.`);
          return this.destroy();
      }

      setTimeout(() => this.play(), 2000); // Auto-recovery with 2s delay
    });
  }

  private vibeLoop: any = null;

  private _startVibeLoop() {
    this._stopVibeLoop();
    this.vibeLoop = setInterval(() => {
        if (this.stopped || !this.current) return this._stopVibeLoop();
        
        // 1. Update Bot Presence
        this.client.user.setPresence({
            activities: [{
                name: `🎧 ${this.current.info.title} | ${this.client.utils.humanize(this.player.position)}`,
                type: 2 // Listening
            }],
            status: "online"
        });
    }, 20000);
  }

  private _stopVibeLoop() {
    if (this.vibeLoop) {
        clearInterval(this.vibeLoop);
        this.vibeLoop = null;
    }
  }

  private async _sendPlayerCard() {
    const RaahiPlayer = (await import("../base/RaahiPlayer.js")).default;
    const playerCard = await new RaahiPlayer(this.client).build(this.current, this.player);
    const attachment = playerCard ? this.client.utils.attachment(playerCard) : null;

    // Matching User reference layout
    const row1 = this.client.utils.actionRow([
      this.client.utils.button(`custom_id`, "Previous", 1, `raahi_previous`, null, this.client.emoji.setup.previous),
      this.client.utils.button(`custom_id`, "Pause", 3, `raahi_pause`, null, this.client.emoji.setup.pause),
      this.client.utils.button(`custom_id`, "Skip", 1, `raahi_skip`, null, this.client.emoji.setup.skip),
      this.client.utils.button(`custom_id`, "Loop", 4, `raahi_loop`, null, this.client.emoji.setup.loop),
      this.client.utils.button(`custom_id`, "Autoplay", 3, `raahi_autoplay`, null, this.client.emoji.setup.autoplay),
    ]);

    const row2 = this.client.utils.actionRow([
      this.client.utils.button(`custom_id`, null, 2, `raahi_shuffle`, null, this.client.emoji.setup.shuffle),
      this.client.utils.button(`custom_id`, null, 2, `raahi_volLow`, null, this.client.emoji.setup.volLow),
      this.client.utils.button(`custom_id`, null, 2, `raahi_volHigh`, null, this.client.emoji.setup.volHigh),
      this.client.utils.button(`custom_id`, "Stop", 4, `raahi_stop`, null, this.client.emoji.setup.stop),
      this.client.utils.button(`custom_id`, null, 2, `raahi_fav`, null, this.client.emoji.setup.fav),
    ]);

    const filterOptions = [
      this.client.utils.menuOption("🎵 Reset Filters", this.client.emoji.fallbacks.reset, "Clear all audio filters", "raahi_filter_reset"),
      this.client.utils.menuOption("🌌 8D Audio", this.client.emoji.fallbacks.filter, "Immersive 8D surround sound", "raahi_filter_8d"),
      this.client.utils.menuOption("💥 Bassboost", this.client.emoji.fallbacks.filter, "Heavy bass boost", "raahi_filter_bassboost"),
      this.client.utils.menuOption("🌙 Nightcore", this.client.emoji.fallbacks.filter, "Fast & high-pitched", "raahi_filter_nightcore"),
      this.client.utils.menuOption("✨ Vaporwave", this.client.emoji.fallbacks.filter, "Chill retro vibes", "raahi_filter_vaporwave"),
    ];

    const filterMenu = this.client.utils.menu("🎛️ Audio Filters", "raahi_filters_menu", filterOptions);
    const filterRow = this.client.utils.actionRow([filterMenu]);

    if (this.client.utils.getDj(this.guild.id)?.CHANNEL !== this.channel.id) {
      const payload: any = { components: [filterRow, row1, row2] };
      if (attachment) payload.files = [attachment];
      else payload.embeds = [this.client.utils.premiumEmbed(this.guild.id).setTitle(`🌌 Now Playing: ${this.current.info.title}`)];

      this.channel?.send(payload).then((x: any) => this.data.set("Raahi", x)).catch(() => {});
    }
  }

  get raahi() {
    return this.client.api.has(this.guild.id);
  }

  public play() {
    if (!this.raahi) return this.destroy();
    if (!this.queue.length) return;

    // Smart duplicate prevention
    let nextTrack = this.queue.shift();
    
    // Remove duplicates from queue
    this.queue = this.queue.filter((t: any) => 
      t.info.identifier !== nextTrack.info.identifier
    );

    this.current = nextTrack;
    // Shoukaku v4: playTrack takes an object
    this.player.playTrack({ track: { encoded: this.current.track } }).catch((e: any) => {
      console.error("[Raahi Play Error]", e);
      this.play();
    });
  }

  public async destroy() {
    this.queue.length = 0;
    this.previous = null;
    this.current = null;
    this.stopped = true;
    try {
      this.data.get("Raahi")?.delete();
    } catch (_) {}
    this.data.delete("Raahi");

    if (this.client.utils.checkDjSetup(this.guild.id) === true) {
      this.updateDj(this.guild);
      this.updateQueue(this.guild, this.queue);
    }

    await this.client.kazagumo.destroyPlayer(this.guild.id);
    this.client.api.delete(this.guild.id);

    if (this.client.utils.get247(this.guild.id) === true) {
      let node = this.client.shoukaku.getNode();
      return this.client.api.reconnect(
        this.guild,
        this.guild.channels.cache.get(get247Set(this.guild.id).CHANNELID),
        this.guild.channels.cache.get(get247Set(this.guild.id).TEXTID),
        node
      );
    }
  }

  // Futuristic AI-powered Autoplay
  private async futuristicAutoplay() {
    if (this.queue.length) return this.play();

    if (!this.previous) {
      // Default cosmic track
      const defaultTrack = await this._getSmartTrack("lofi chill");
      if (defaultTrack) {
        this.current = defaultTrack;
        this.player.playTrack({ track: { encoded: this.current.track } });
        return;
      }
    }

    try {
      // Smart AI Recommendation based on previous track
      const identifier = this.previous?.info?.identifier || "dQw4w9wgxcQ";
      const url = `https://youtube.com/watch?v=${identifier}&list=RD${identifier}`;

      let node = this.client.shoukaku.getNode();
      let result = await this.client.utils.resolve(node, url).catch(() => null);

      if (!result?.tracks?.length) {
        return this.player.stopTrack();
      }

      // Futuristic: Smart selection (avoid duplicates, pick best match)
      let track = result.tracks.find((t: any) =>
        !this.queue.some((q: any) => q.info.identifier === t.info.identifier)
      ) || result.tracks[Math.floor(Math.random() * result.tracks.length)];

      track.info.requester = this.client.user;
      this.current = this.client.utils.track(track);
      this.player.playTrack({ track: { encoded: this.current.track } });

      // Queue a few more AI suggestions for futuristic experience
      if (this.smartQueue && result.tracks.length > 3) {
        const suggestions = result.tracks.slice(1, 4).map((t: any) => {
          t.info.requester = this.client.user;
          return this.client.utils.track(t);
        });
        this.queue.push(...suggestions);
      }
    } catch (e) {
      console.error("[Futuristic Autoplay Error]", e);
      this.player.stopTrack();
    }
  }

  // Helper: Get a smart track
  private async _getSmartTrack(query: string) {
    try {
      let node = this.client.shoukaku.getNode();
      let res = await this.client.utils.resolve(node, `ytsearch:${query}`).catch(() => null);
      if (res?.tracks?.length) {
        let t = res.tracks[0];
        t.info.requester = this.client.user;
        return this.client.utils.track(t);
      }
    } catch (_) {}
    return null;
  }

  public async updateDj(guild?: any) {
    // Throttled visual update to prevent rate limits
    const g = guild || this.guild;
    if (!g || !this.client.utils.checkDjSetup(g.id)) return;
    
    // Check if we've updated in the last 2 seconds
    const lastUpdate = this.data.get("last_dj_update") || 0;
    if (Date.now() - lastUpdate < 2000) return;
    this.data.set("last_dj_update", Date.now());

    let setup = this.client.utils.getDj(g.id);
    if (!setup) return;
    let ch = await g.channels.fetch(setup.CHANNEL).catch(() => null);
    if (!ch) return;
    let msg = await ch.messages.fetch(setup.MESSAGE).catch(() => null);
    if (!msg) return;

    if (this.current !== null && !this.stopped) {
      const RaahiPlayer = (await import("../base/RaahiPlayer.js")).default;
      const playerCard = await new RaahiPlayer(this.client).build(this.current, this.player);
      const attachment = playerCard ? this.client.utils.attachment(playerCard) : null;

      const payload: any = {
        embeds: [],
        files: []
      };

      if (attachment) {
        payload.files = [attachment];
      } else {
        payload.embeds = [
          this.client.utils
            .embed()
            .setAuthor({
              name: `Quantum Dashboard | Active Session`,
              iconURL: this.client.user.displayAvatarURL(),
            })
            .setTitle(`🌌 ${this.current.info.title.substring(0, 50)}`)
            .setDescription(
              `🎤 **Artist:** \`${this.current.info.author}\`\n` +
              `⏱️ **Duration:** \`${this.client.utils.humanize(this.current.info.length)}\`\n` +
              `🌸 **Requester:** \`${this.current.info.requester?.tag || "Anonymous"}\`\n\n` +
              `${this.client.utils.progressBar(this.player.position || 0, this.current.info.length, 20)}`
            )
            .setImage(`${this.client.config.setupBgLink}`)
            .setThumbnail(`https://img.youtube.com/vi/${this.current.info.identifier}/hqdefault.jpg`)
            .setFooter({
              text: `🚀 Raahi Futuristic • Powered by Quantum AI`,
              iconURL: this.client.user.displayAvatarURL(),
            }),
        ];
      }

      await msg.edit(payload).catch(() => {});
    } else {
      await msg.edit({
        embeds: [
          this.client.utils
            .embed()
            .setAuthor({
              name: `Quantum Lounge | Idle`,
              iconURL: this.client.user.displayAvatarURL(),
            })
            .setTitle(`🌌 Raahi Quantum Hub`)
            .setDescription(
              `🫧 *Ready for the future of music!* Send a song name or link below to start the cosmic journey.\n\n` +
              `✨ **Active Mode:** \`Quantum AI\`\n` +
              `🛸 **Status:** \`Waiting for Command\``
            )
            .setURL(`${this.client.config.voteUrl}`)
            .setImage(`${this.client.config.setupBgLink}`)
            .setFooter({
              text: `Made with 💖 by Raahi Team • Futuristic Music AI`,
              iconURL: this.client.user.displayAvatarURL(),
            }),
        ],
      }).catch(() => {});
    }
  }

  public async updateQueue(guild: any, queue: any[]) {
    // Throttled queue update
    const lastUpdate = this.data.get("last_queue_update") || 0;
    if (Date.now() - lastUpdate < 3000) return;
    this.data.set("last_queue_update", Date.now());

    let setup = this.client.utils.checkDjSetup(guild?.id);
    if (!setup) return;
    let set = this.client.utils.getDj(guild?.id);
    let ch = await this.guild.channels.fetch(set.CHANNEL).catch(() => null);
    if (!ch) return;

    let q: any = "*No songs in the quantum queue yet...*";
    if (queue.length > 0) {
      q = queue.slice(0, 8).map((x: any, i: number) =>
        `**${i + 1}.** ${x.info.title.substring(0, 42)} • \`${this.client.utils.humanize(x.info.length)}\``
      ).join("\n");
      if (queue.length > 8) q += `\n✨ **+${queue.length - 8}** more in the multiverse queue!`;
    }

    ch.messages.fetch(set.MESSAGE).then((x: any) => {
      x.edit({
        content: `🌌 **Raahi Quantum Station • Live Queue** 🌌\n🫧 *Type song names or URLs here to instantly play!*\n\n📜 **Cosmic Queue:**\n${q}`,
      }).catch(() => {});
    }).catch(() => {});
  }

  // Enhanced futuristic filter system
  public async setFilter(name: string): Promise<boolean> {
    const n = name.toLowerCase();
    if (this.filter.toLowerCase() === n && n !== "clear" && n !== "none") {
      await this.player.setFilters({}).catch(() => {});
      this.filter = "none";
      return false;
    }

    if (n === "clear" || n === "none" || n === "reset") {
      await this.player.setFilters({}).catch(() => {});
      this.filter = "none";
      return true;
    }

    // All previous filters + futuristic extras
    const filters: { [key: string]: any } = {
      "8d": { rotation: { rotationHz: 0.2 } },
      "bassboost": { equalizer: [{ band: 0, gain: 0.35 }, { band: 1, gain: 0.3 }, { band: 2, gain: 0.25 }] },
      "nightcore": { timescale: { speed: 1.25, pitch: 1.3 } },
      "vaporwave": { timescale: { speed: 0.85, pitch: 0.75 }, tremolo: { depth: 0.3, frequency: 14 } },
      "daycore": { timescale: { speed: 0.85, pitch: 0.7 }, equalizer: [{ band: 0, gain: 0.2 }] },
      "pop": { equalizer: [{ band: 0, gain: -0.05 }, { band: 2, gain: 0.3 }, { band: 4, gain: 0.25 }] },
      "enhance": { equalizer: [{ band: 0, gain: 0.15 }, { band: 11, gain: 0.25 }, { band: 14, gain: 0.35 }] },
    };

    if (filters[n]) {
      await this.player.setFilters(filters[n]).catch(() => {});
      this.filter = name.charAt(0).toUpperCase() + name.slice(1);
      return true;
    }

    // fallback to original logic for other filters
    return await this._legacyFilter(n);
  }

  private async _legacyFilter(n: string) {
    // Original filter logic kept for compatibility
    if (n === "china") {
      await this.player.setFilters({ timescale: { speed: 0.75, pitch: 1.25 } }).catch(() => {});
      this.filter = "China";
      return true;
    }
    // ... (other legacy filters remain)
    return false;
  }

  private async autoplay() {
    // Legacy autoplay
    if (this.queue.length) return this.play();
    let identifier = this.previous?.info?.identifier || "_XBVWlI8TsQ";
    let url = `https://youtube.com/watch?v=${identifier}&list=RD${identifier}`;
    let node = this.client.shoukaku.getNode();
    let result = await this.client.utils.resolve(node, url).catch(() => null);
    if (!result?.tracks?.length) return this.player.stopTrack();

    let track = result.tracks[Math.floor(Math.random() * result.tracks.length)];
    track.info.requester = this.client.user;
    this.current = this.client.utils.track(track);
    this.player.playTrack({ track: { encoded: this.current.track } });
  }
}
