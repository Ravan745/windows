import RaahiDatabase from "../../database/db.js";

const db = new RaahiDatabase("queues.sqlite");

let __init_createQueue = false;
function createQueue(): void {
  if (__init_createQueue) return;
  db.prepare(
    `CREATE TABLE IF NOT EXISTS QUEUE_SYNC(
        GUILD TEXT PRIMARY KEY,
        DATA TEXT
    )`
  ).run();
  __init_createQueue = true;
}

export function saveGuildQueue(guildId: string, data: any) {
  createQueue();
  const syncData = JSON.stringify({
    current: data.current,
    queue: data.queue,
    repeat: data.repeat,
    savedAt: Date.now()
  });
  db.prepare(`INSERT OR REPLACE INTO QUEUE_SYNC(GUILD, DATA) VALUES(?, ?)`).run(guildId, syncData);
}

export function getGuildQueue(guildId: string) {
  createQueue();
  const row = db.prepare(`SELECT DATA FROM QUEUE_SYNC WHERE GUILD = ?`).get(guildId);
  if (row) return JSON.parse((row as any).DATA);
  return null;
}

export function clearGuildQueue(guildId: string) {
  createQueue();
  db.prepare(`DELETE FROM QUEUE_SYNC WHERE GUILD = ?`).run(guildId);
}
