import fs from "fs";
import path from "path";

const dataDir = path.join(process.cwd(), "data");
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const favPath = path.join(dataDir, "favorites.json");

if (!fs.existsSync(favPath)) {
  fs.writeFileSync(favPath, JSON.stringify({}));
}

function loadFavs() {
  try {
    return JSON.parse(fs.readFileSync(favPath, "utf8"));
  } catch {
    return {};
  }
}

function saveFavs(data: any) {
  fs.writeFileSync(favPath, JSON.stringify(data, null, 2));
}

export function addFavorite(userId: string, track: any) {
  const data = loadFavs();
  if (!data[userId]) data[userId] = [];
  
  // Avoid duplicates
  if (!data[userId].some((t: any) => t.info.identifier === track.info.identifier)) {
    data[userId].push(track);
    saveFavs(data);
    return true;
  }
  return false;
}

export function getFavorites(userId: string) {
  const data = loadFavs();
  return data[userId] || [];
}

export function removeFavorite(userId: string, identifier: string) {
  const data = loadFavs();
  if (!data[userId]) return false;
  const before = data[userId].length;
  data[userId] = data[userId].filter((t: any) => t.info.identifier !== identifier);
  saveFavs(data);
  return data[userId].length < before;
}

export function clearFavorites(userId: string) {
  const data = loadFavs();
  delete data[userId];
  saveFavs(data);
}
