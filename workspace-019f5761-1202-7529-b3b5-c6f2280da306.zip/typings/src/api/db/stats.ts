import RaahiDatabase from "../../database/db.js";

const db = new RaahiDatabase("stats.sqlite");

let __init_createStats = false;
function createStats(): void {
  if (__init_createStats) return;
  db.prepare(
    `CREATE TABLE IF NOT EXISTS BILLBOARD(
        GUILD TEXT,
        TITLE TEXT,
        AUTHOR TEXT,
        PLAYS INTEGER,
        UNIQUE(GUILD, TITLE, AUTHOR)
    )`
  ).run();
  db.prepare(
    `CREATE TABLE IF NOT EXISTS USER_STATS(
        USER TEXT,
        TITLE TEXT,
        AUTHOR TEXT,
        PLAYS INTEGER,
        UNIQUE(USER, TITLE, AUTHOR)
    )`
  ).run();
  __init_createStats = true;
}

function incrementPlayCount(guild: string, user: string, title: string, author: string): void {
  createStats();
  // Server stats
  db.prepare(
    `INSERT INTO BILLBOARD(GUILD, TITLE, AUTHOR, PLAYS) 
     VALUES(?, ?, ?, 1) 
     ON CONFLICT(GUILD, TITLE, AUTHOR) 
     DO UPDATE SET PLAYS = PLAYS + 1`
  ).run(guild, title, author);

  // User stats (for Vibe Match)
  db.prepare(
    `INSERT INTO USER_STATS(USER, TITLE, AUTHOR, PLAYS) 
     VALUES(?, ?, ?, 1) 
     ON CONFLICT(USER, TITLE, AUTHOR) 
     DO UPDATE SET PLAYS = PLAYS + 1`
  ).run(user, title, author);
}

function getTopTracks(guild: string | null, limit = 5): any[] {
  createStats();
  if (guild) {
    return db.prepare(
      `SELECT TITLE, AUTHOR, SUM(PLAYS) as PLAYS FROM BILLBOARD WHERE GUILD = ? GROUP BY TITLE, AUTHOR ORDER BY PLAYS DESC LIMIT ?`
    ).all(guild, limit);
  } else {
    // Global Billboard
    return db.prepare(
      `SELECT TITLE, AUTHOR, SUM(PLAYS) as PLAYS FROM BILLBOARD GROUP BY TITLE, AUTHOR ORDER BY PLAYS DESC LIMIT ?`
    ).all(limit);
  }
}

function getUserVibe(user: string): any[] {
    createStats();
    return db.prepare(`SELECT TITLE, AUTHOR FROM USER_STATS WHERE USER = ? ORDER BY PLAYS DESC LIMIT 20`).all(user);
}

export { incrementPlayCount, getTopTracks, getUserVibe };

