import fs from "fs";
import path from "path";

const dataDir = path.join(process.cwd(), "data");
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const perksPath = path.join(dataDir, "premiumPerks.json");

if (!fs.existsSync(perksPath)) {
  fs.writeFileSync(perksPath, JSON.stringify({}));
}

function loadPerks() {
  try {
    return JSON.parse(fs.readFileSync(perksPath, "utf8"));
  } catch {
    return {};
  }
}

function savePerks(data: any) {
  fs.writeFileSync(perksPath, JSON.stringify(data, null, 2));
}

export function hasPremium(userId: string) {
  const data = loadPerks();
  return data[userId]?.active || false;
}

export function getPremiumPerks(userId: string) {
  const data = loadPerks();
  if (!data[userId] || !data[userId].active) {
    return {
      queueLimit: 100,
      customImage: false,
      priorityQueue: false,
      allFilters: false,
      noCooldown: false
    };
  }
  return data[userId].perks || {
    queueLimit: 9999,
    customImage: true,
    priorityQueue: true,
    allFilters: true,
    noCooldown: true
  };
}

export function activatePremium(userId: string, days = 30) {
  const data = loadPerks();
  data[userId] = {
    active: true,
    expires: Date.now() + (days * 24 * 60 * 60 * 1000),
    perks: {
      queueLimit: 9999,
      customImage: true,
      priorityQueue: true,
      allFilters: true,
      noCooldown: true
    }
  };
  savePerks(data);
}
