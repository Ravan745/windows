import fs from "fs";
import path from "path";

const dataDir = path.join(process.cwd(), "data");
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const playlistPath = path.join(dataDir, "playlists.json");

if (!fs.existsSync(playlistPath)) {
  fs.writeFileSync(playlistPath, JSON.stringify({}));
}

function loadPlaylists() {
  try {
    return JSON.parse(fs.readFileSync(playlistPath, "utf8"));
  } catch {
    return {};
  }
}

function savePlaylists(data: any) {
  fs.writeFileSync(playlistPath, JSON.stringify(data, null, 2));
}

export function createPlaylist(userId: string, name: string) {
  const data = loadPlaylists();
  if (!data[userId]) data[userId] = {};
  if (data[userId][name]) return false;
  data[userId][name] = { tracks: [], created: Date.now() };
  savePlaylists(data);
  return true;
}

export function addToPlaylist(userId: string, name: string, track: any) {
  const data = loadPlaylists();
  if (!data[userId] || !data[userId][name]) return false;
  data[userId][name].tracks.push(track);
  savePlaylists(data);
  return true;
}

export function getPlaylist(userId: string, name: string) {
  const data = loadPlaylists();
  if (!data[userId] || !data[userId][name]) return null;
  return data[userId][name];
}

export function listPlaylists(userId: string) {
  const data = loadPlaylists();
  if (!data[userId]) return [];
  return Object.keys(data[userId]).map(name => ({
    name,
    created: data[userId][name].created,
    count: data[userId][name].tracks.length
  }));
}

export function deletePlaylist(userId: string, name: string) {
  const data = loadPlaylists();
  if (!data[userId] || !data[userId][name]) return false;
  delete data[userId][name];
  savePlaylists(data);
  return true;
}
