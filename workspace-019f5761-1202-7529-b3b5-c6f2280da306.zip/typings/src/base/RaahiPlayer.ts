import { createCanvas, loadImage } from "@napi-rs/canvas";
import * as Vibrant from "node-vibrant";
import { getTheme } from "../api/db/dj.js";
import { getTopTracks } from "../api/db/stats.js";

function drawRoundRect(ctx: any, x: number, y: number, width: number, height: number, radius: number) {
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + width - radius, y);
  ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
  ctx.lineTo(x + width, y + height - radius);
  ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
  ctx.lineTo(x + radius, y + height);
  ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
  ctx.lineTo(x, y + radius);
  ctx.quadraticCurveTo(x, y, x + radius, y);
  ctx.closePath();
}

export default class RaahiPlayer {
  client: any;
  constructor(client: any) {
    this.client = client;
  }
  async build(track: any, player: any) {
    try {
      const canvas = createCanvas(800, 320);
      const ctx = canvas.getContext("2d");

      const guildTheme = getTheme(player.guildId);
      const thumbUrl = `https://img.youtube.com/vi/${track.info.identifier}/maxresdefault.jpg`;
      let vibrantColor = "#FF85A2";

      try {
        const palette = await (Vibrant as any).default.from(thumbUrl).getPalette();
        vibrantColor = palette?.Vibrant?.getHex() || "#FF85A2";
      } catch (e) {}

      // 1. Holographic Glassmorphism Background
      ctx.fillStyle = "#0c0d10";
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Gradient Glow Layer
      const grad = ctx.createRadialGradient(400, 160, 100, 400, 160, 600);
      grad.addColorStop(0, `${vibrantColor}33`); // 20% opacity
      grad.addColorStop(1, "#00000000");
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Glass Card
      ctx.save();
      ctx.globalAlpha = 0.8;
      drawRoundRect(ctx, 20, 20, 760, 280, 35);
      ctx.fillStyle = "#1c1c1c66"; // Frosted glass effect
      ctx.fill();
      ctx.restore();

      // Card Border with Glow
      ctx.save();
      ctx.shadowBlur = 20;
      ctx.shadowColor = vibrantColor;
      ctx.strokeStyle = vibrantColor;
      ctx.lineWidth = 2;
      drawRoundRect(ctx, 20, 20, 760, 280, 35);
      ctx.stroke();
      ctx.restore();

      // 2. Thumbnail with Shadow
      try {
        let image = await loadImage(thumbUrl).catch(async () => {
          return await loadImage(`https://img.youtube.com/vi/${track.info.identifier}/mqdefault.jpg`).catch(() => null);
        });
        
        if (image) {
          ctx.save();
          ctx.shadowBlur = 30;
          ctx.shadowColor = "rgba(0,0,0,0.8)";
          drawRoundRect(ctx, 50, 50, 220, 220, 30);
          ctx.clip();
          ctx.drawImage(image, 50, 50, 220, 220);
          ctx.restore();
          
          // Gloss overlay on thumbnail
          const gloss = ctx.createLinearGradient(50, 50, 270, 270);
          gloss.addColorStop(0, "rgba(255,255,255,0.1)");
          gloss.addColorStop(0.5, "rgba(255,255,255,0)");
          gloss.addColorStop(1, "rgba(255,255,255,0.05)");
          ctx.fillStyle = gloss;
          drawRoundRect(ctx, 50, 50, 220, 220, 30);
          ctx.fill();
        }
      } catch (e) {}

      // 3. Track Info (Glassy Style)
      const textX = 300;
      
      // Title
      ctx.fillStyle = "#FFFFFF";
      ctx.font = "bold 38px sans-serif";
      const title = track.info.title.length > 22 ? track.info.title.substring(0, 19) + "..." : track.info.title;
      ctx.fillText(title, textX, 100);

      // Artist
      ctx.fillStyle = "#9ba3a4";
      ctx.font = "24px sans-serif";
      const author = track.info.author.length > 25 ? track.info.author.substring(0, 22) + "..." : track.info.author;
      ctx.fillText(author, textX, 140);

      // Check for Main Character Crown
      const topTracks = getTopTracks(player.guildId, 1);
      const isMainCharacter = topTracks.length > 0 && topTracks[0].TITLE === track.info.title;

      // Requester Info
      ctx.font = "20px sans-serif";
      ctx.fillStyle = "#ffffff99";
      ctx.fillText(`Requested by:`, textX, 185);
      
      ctx.fillStyle = vibrantColor;
      const reqName = track.info.requester?.username || "Quantum Ghost";
      ctx.fillText(reqName, textX + 135, 185);

      if (isMainCharacter) {
          ctx.font = "24px sans-serif";
          ctx.fillText(" 👑", textX + 135 + ctx.measureText(reqName).width, 185);
      }

      // 4. Progress UI
      const progX = 300;
      const progY = 220;
      const progWidth = 440;
      
      // Background Bar
      drawRoundRect(ctx, progX, progY, progWidth, 8, 4);
      ctx.fillStyle = "rgba(255, 255, 255, 0.1)";
      ctx.fill();

      // Active Bar
      const pos = player.position || 0;
      const currentProg = (pos / track.info.length) * progWidth;
      if (currentProg > 0) {
        ctx.save();
        ctx.shadowBlur = 10;
        ctx.shadowColor = vibrantColor;
        drawRoundRect(ctx, progX, progY, currentProg, 8, 4);
        ctx.fillStyle = vibrantColor;
        ctx.fill();
        ctx.restore();
      }

      // Timestamps
      ctx.font = "16px monospace";
      ctx.fillStyle = "#9ba3a4";
      ctx.fillText(this.client.utils.humanize(player.position), progX, 250);
      const total = this.client.utils.humanize(track.info.length);
      ctx.fillText(total, progX + progWidth - ctx.measureText(total).width, 250);

      // 5. Aesthetic Pixel Glitch corner
      ctx.fillStyle = vibrantColor;
      ctx.globalAlpha = 0.3;
      ctx.fillRect(770, 30, 10, 10);
      ctx.fillRect(755, 30, 5, 10);
      ctx.fillRect(770, 45, 10, 5);

      return canvas.toBuffer("image/png");
    } catch (e) {
      console.log(e);
      return null;
    }
  }
}
