import Raahi from "./structures/Client.js";
import RaahiConfig from "./config/Config.js";

const Config = new RaahiConfig();
const client = new Raahi();

// Futuristic boot sequence
console.log(`
🌌 ═══════════════════════════════════════════════════════════ 🌌
   ✨  AVON 6.0 • FUTURISTIC AI MUSIC BOT • CUTE COSMIC EDITION  ✨
🌌 ═══════════════════════════════════════════════════════════ 🌌
`);

client.start().then(() => {
  console.log(`🚀 Raahi connected to the multiverse successfully!`);
}).catch((e) => {
  console.error(`[Quantum Error] Failed to initialize Raahi:`, e);
});

// Futuristic global error handling
["unhandledRejection", "uncaughtException", "warning"].forEach((x: string) => {
  process.on(x, (e: any) => {
    if (e && (e.code === 10062 || e.code === 40060 || e.code === 50035 || e.code === 10008 || e.code === 10062)) return;
    
    if (x === "warning") {
      console.warn(`[Futuristic Warning]:`, e?.message || e);
      return;
    }
    
    console.error(`[Worker Quantum Error - ${x}]:`, e?.stack || e);
  });
});

// Graceful shutdown for futuristic bots
process.on("SIGINT", () => {
  console.log(`\n🌸 Raahi gracefully shutting down... See you in the next cosmic cycle! ✨`);
  process.exit(0);
});

export default client;
