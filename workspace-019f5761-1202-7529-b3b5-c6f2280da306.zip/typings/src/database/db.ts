import { mkdirSync } from "node:fs";
import { dirname } from "node:path";
import { DatabaseSync } from "node:sqlite";

export default class RaahiDatabase {
  private readonly database: DatabaseSync;

  constructor(path: string) {
    const databasePath = `./data/database/${path}`;
    mkdirSync(dirname(databasePath), { recursive: true });

    this.database = new DatabaseSync(databasePath, {
      open: true,
      readOnly: false,
    });
    this.pragma("journal_mode=WAL");
  }

  public prepare(sql: string) {
    return this.database.prepare(sql);
  }

  public exec(sql: string) {
    return this.database.exec(sql);
  }

  public pragma(sql: string) {
    return this.database.exec(`PRAGMA ${sql}`);
  }

  public close() {
    return this.database.close();
  }
}
