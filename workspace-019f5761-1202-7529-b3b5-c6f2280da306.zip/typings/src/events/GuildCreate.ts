import { ChannelType, PermissionFlagsBits, WebhookClient } from "discord.js";
import RaahiEvent from "../base/RaahiEvent.js";

export default class GuildCreate extends RaahiEvent {
  [x: string]: any;
  constructor(client: any) {
    super(client);
    this.name = "guildCreate";
    this.run = async (guild: any) => {
      let web: WebhookClient | null = null;
      if (this.client.config?.webhooks?.guildCreate && this.client.config.webhooks.guildCreate !== "") {
        try {
          web = new WebhookClient({
            url: this.client.config.webhooks.guildCreate,
          });
        } catch (e) {}
      }

      let mainChannel: any;
      guild.channels.cache.forEach((x: any) => {
        if (
          client.utils.getBotMember(guild)
            .permissionsIn(x)
            .has([
              PermissionFlagsBits.SendMessages,
              PermissionFlagsBits.ViewChannel,
            ]) &&
          x.type === ChannelType.GuildText &&
          !mainChannel
        )
          mainChannel = x;
      });

      let mb = this.client.utils
        .embed()
        .setTitle(`🌸 ✨ • Slay Bestie! Welcome to ${this.client.user.username} • ✨ 🌸`)
        .setAuthor({
          name: `Omg hi bestie! Thanks so much for inviting me! 🎀 💖`,
          iconURL: this.client.user.displayAvatarURL(),
        })
        .setDescription(
          `Slay bestie! I am **${this.client.user.username}**, your ultra-cute Gen-Z aesthetic 24/7 music companion serving clean, crystal-clear vibes across **YouTube**, **Spotify**, **Deezer**, and **SoundCloud**! 🫧🎧✨\n\n` +
          `• **My default server prefix:** \`${this.client.config.prefix}\` *(or use Slash Commands \`/\` literally anywhere!)*\n` +
          `• **Explore all commands:** \`${this.client.config.prefix}help\` or \`/help\`\n` +
          `• **Setup interactive music lounge:** \`${this.client.config.prefix}setup dj create\` or \`/setup subcommand: dj value: create\`\n\n` +
          `If u ever need any help or wanna hang out with our aesthetic community, join our **[Support Server](${this.client.config.server})** anytime! No cap, we gotchu! 💖🌷`
        )
        .setThumbnail(guild.iconURL({ dynamic: true }) || this.client.user.displayAvatarURL())
        .setFooter({
          text: `Made with 💖 by Raahi • Serving immaculate music vibes ✨`,
          iconURL: this.client.user.displayAvatarURL(),
        })
        .setTimestamp();

      let b1 = this.client.utils.button(
        `link`,
        `Support Server`,
        null,
        null,
        `${this.client.config.server}`,
        null
      );
      let b2 = this.client.utils.button(
        `link`,
        `Get Premium`,
        null,
        null,
        `${this.client.config.server}`,
        null
      );
      let b3 = this.client.utils.button(
        `link`,
        `Vote Me`,
        null,
        null,
        `${this.client.config.voteUrl}`
      );
      let row = this.client.utils.actionRow([b1, b2, b3]);
      if (mainChannel) {
        mainChannel.send({
          embeds: [mb],
          components: [row],
        }).catch(() => {});
      }

      let invite: any = null;
      if (mainChannel) {
        invite = await mainChannel.createInvite({ maxAge: 0 }).catch(() => null);
      }
      let inviteStr = invite && invite.url ? invite.url : "Unable to fetch invite";

      let ownerMember = await guild.members.fetch(guild.ownerId).catch(() => null);
      let ownerTag = ownerMember ? ownerMember.user.tag : "Unknown Owner";

      let em = this.client.utils
        .embed()
        .setTitle(`🌸 Guild Joined • ${guild.name} ✨`)
        .setThumbnail(guild.iconURL({ dynamic: true }) || this.client.user.displayAvatarURL())
        .addFields([
          {
            name: `📋 • Server Info`,
            value: `**• Name:** ${guild.name}\n**• ID:** \`${guild.id}\`\n**• Owner:** \`${ownerTag}\`\n**• Members:** \`${guild.memberCount}\` besties`,
          },
          {
            name: `🔗 • Invite`,
            value: `${inviteStr}`,
          },
        ])
        .setTimestamp();

      if (web) web.send({ embeds: [em] }).catch(() => {});
    };
  }
}
