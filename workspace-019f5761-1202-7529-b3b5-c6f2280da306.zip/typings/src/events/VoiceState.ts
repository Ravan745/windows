import RaahiEvent from "../base/RaahiEvent.js";

export default class VoiceState extends RaahiEvent {
  [x: string]: any;
  constructor(client: any) {
    super(client);
    this.name = "voiceStateUpdate";
    this.run = async (oldState: any, newState: any) => {
      const dispatcher = this.client.api.get(newState.guild.id);
      if (!dispatcher || !dispatcher?.player) return;

      const botMember = this.client.utils.getBotMember(newState.guild);
      if (!botMember) return;

      if (oldState.id === this.client.user.id) return;

      if (botMember.voice.serverMute || newState.serverMute) {
        botMember.voice.setMute(false).catch(() => {});
      }

      let data = this.client.utils.get247(newState.guild.id);
      if (data === false) {
        if (botMember.voice.channel?.id === oldState.channel?.id) {
          if (
            botMember.voice?.channel &&
            botMember.voice?.channel?.members.filter((m: any) => !m.user.bot).size === 0
          ) {
            const aloneSince = Date.now();
            setTimeout(() => {
              const currentBotMember = newState.guild.members.me || newState.guild.members.cache.get(this.client.user.id);
              if (
                currentBotMember?.voice?.channel &&
                currentBotMember.voice.channel.members.filter((m: any) => !m.user.bot).size === 0 &&
                dispatcher.raahi // verify dispatcher still exists
              ) {
                let em = this.client.utils
                  .premiumEmbed(newState.guild.id)
                  .setTitle(`🌸 ✨ • Left Voice Channel • ✨ 🌸`)
                  .setDescription(
                    `🥺 *Bestie, everyone left the voice channel so I hopped out too since \`24/7\` mode is off! Join back and summon me whenever u wanna vibe again!* 🎧💖`
                  );
                dispatcher.destroy();
                dispatcher.channel
                  ?.send({ embeds: [em] })
                  .then((x: any) => {
                    setTimeout(() => x?.delete()?.catch(() => {}), 10000);
                  })
                  .catch(() => {});
              }
            }, 180000);
          }
        }
      }
    };
  }
}
