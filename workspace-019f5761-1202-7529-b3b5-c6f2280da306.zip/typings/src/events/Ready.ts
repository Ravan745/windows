import RaahiEvent from "../base/RaahiEvent.js";
import { REST, Routes, SlashCommandBuilder } from "discord.js";
import { getGuildQueue } from "../api/db/queue.js";

export default class Ready extends RaahiEvent {
  [x: string]: any;
  constructor(client: any) {
    super(client);
    this.name = "clientReady";
    this.run = async () => {
      this.client.logger.ready(`${this.client.user.username} is Online! ✨🌸`);

      if (this.client.user && this.client.token && this.client.cluster.id === 0) {
        try {
          const rest = new REST({ version: "10" }).setToken(this.client.token);
          const slashCommands: any[] = [];
          this.client.commands.messages.forEach((cmd: any) => {
            // Strictly exclude ALL owner/developer commands from Slash Commands
            // This checks the category name, the dev flag, and specific owner-only categories
            const category = cmd.cat?.toLowerCase() || "";
            if (
              !cmd || 
              !cmd.name || 
              cmd.dev === true || 
              category === "developer" || 
              category === "rihan" || 
              category === "owner" ||
              category === "dev"
            ) return;
            
            let builder = new SlashCommandBuilder()
              .setName(cmd.name.toLowerCase().replace(/[^a-z0-9_-]/g, "-").substring(0, 32))
              .setDescription((cmd.desc || "Raahi utility or music command").substring(0, 100));

            // Implement Autocomplete for Play command
            if (cmd.name === "play" || cmd.name === "p") {
              builder.addStringOption((o: any) =>
                o.setName("query")
                 .setDescription("Song title, URL, or search query to play")
                 .setRequired(true)
                 .setAutocomplete(true)
              );
            } else if (cmd.name === "volume" || cmd.name === "vol" || cmd.name === "v") {
              builder.addStringOption((o: any) =>
                o.setName("amount").setDescription("Volume percentage (1-100)").setRequired(false)
              );
            } else if (cmd.name === "setup" || cmd.name === "set") {
              builder
                .addStringOption((o: any) =>
                  o.setName("subcommand").setDescription("Choose setting: embed, player, dj, dj-role, play-type, theme").setRequired(false)
                )
                .addStringOption((o: any) =>
                  o.setName("value").setDescription("Action/value: create, delete, fix, config, set, #hex, or theme name").setRequired(false)
                )
                .addStringOption((o: any) =>
                  o.setName("target").setDescription("Channel or role ID/mention if setting dj/djrole").setRequired(false)
                );
            } else if (cmd.name === "billboard" || cmd.name === "top") {
              builder.addStringOption((o: any) =>
                o.setName("type").setDescription("Chart type: local or global").addChoices({ name: "Local", value: "local" }, { name: "Global", value: "global" }).setRequired(false)
              );
            } else if (cmd.name === "match") {
              builder.addUserOption((o: any) =>
                o.setName("user").setDescription("User to check sync with").setRequired(true)
              );
            } else if (cmd.name === "forecast") {
               // No options
            } else if (cmd.name === "ignore" || cmd.name === "ign") {
              builder
                .addStringOption((o: any) =>
                  o.setName("subcommand").setDescription("Subcommand: add, remove, config, bypass, reset").setRequired(false)
                )
                .addStringOption((o: any) =>
                  o.setName("target").setDescription("Channel mention/ID or bypass group (mods/admins)").setRequired(false)
                );
            } else if (cmd.name === "help") {
              builder.addStringOption((o: any) =>
                o.setName("command").setDescription("Command name or category to view help for").setRequired(false)
              );
            } else if (cmd.name === "set-prefix") {
              builder.addStringOption((o: any) =>
                o.setName("prefix").setDescription("New custom prefix (up to 3 characters)").setRequired(false)
              );
            } else if (cmd.name === "247" || cmd.name === "autoplay") {
              builder.addStringOption((o: any) =>
                o.setName("setting").setDescription("Toggle setting: on/enable or off/disable").setRequired(false)
              );
            } else if (cmd.name === "seek" || cmd.name === "remove" || cmd.name === "move" || cmd.name === "lyrics") {
              builder.addStringOption((o: any) =>
                o.setName("input").setDescription("Song index, target time, or song title").setRequired(false)
              );
            } else {
              builder.addStringOption((o: any) =>
                o.setName("input").setDescription("Optional arguments for " + cmd.name).setRequired(false)
              );
            }
            slashCommands.push(builder.toJSON());
          });

          this.client.logger.log(`[Slash] Registering ${slashCommands.length} Application Commands...`);
          await rest.put(Routes.applicationCommands(this.client.user.id), { body: slashCommands });
          this.client.logger.log(`[Slash] Successfully registered all ${slashCommands.length} Slash Commands! ✨🌸`);

      // Restore queues on startup
      setTimeout(() => {
        const guilds = this.client.guilds.cache;
        guilds.forEach(async (guild: any) => {
          const saved = getGuildQueue(guild.id);
          if (saved && saved.queue && saved.queue.length > 0) {
            const dispatcher = this.client.api.get(guild.id);
            if (dispatcher) {
              dispatcher.queue = saved.queue;
              if (saved.current) dispatcher.current = saved.current;
              this.client.logger.log(`Restored queue for ${guild.name}`);
            }
          }
        });
      }, 10000);
        } catch (e: any) {
          this.client.logger.error(`[Slash] Error registering slash commands: ${e?.message || e}`);
        }
      }

      const activities = [
        {
          content: `${this.client.config.prefix}help`,
          type: 0,
          status: `dnd`,
        },
        {
          content: `${this.client.config.prefix}play`,
          type: 2,
          status: `idle`,
        },
        {
          content: `${this.client.config.prefix}setup`,
          type: 3,
          status: `online`,
        },
      ];

      setInterval(() => {
        // Only update random status if not currently playing a vibe
        if (this.client.api.size > 0) return;
        
        let activity = Math.floor(Math.random() * activities.length);
        this.client.user.setPresence({
          activities: [
            {
              name: activities[activity].content,
              type: activities[activity].type,
            },
          ],
          status: activities[activity].status,
        });
      }, 5000);
    };
  }
}
