import { Collection } from "discord.js";
import { addFavs } from "../api/db/premium.js";
import RaahiEvent from "../base/RaahiEvent.js";
import Topgg from "@top-gg/sdk";
import RaahiConfig from "../config/Config.js";

const Config = new RaahiConfig();
const voteApi = Config.voteApi ? new Topgg.Api(Config.voteApi) : null;

async function checkVote(client: any, userId: string): Promise<boolean> {
  if (!voteApi) return true;
  if (client.config.owners.includes(userId)) return true;
  if (client.utils.checkUserPrem(userId)) return true;
  try {
    return await voteApi.hasVoted(userId).catch(() => true);
  } catch (e) {
    return true;
  }
}

export default class RaahiInteraction extends RaahiEvent {
  constructor(client: any) {
    super(client);
    this.name = "interactionCreate";
  }

  run = async (interaction: any) => {
    try {
      if (!interaction.guild) return;

      // 1. Handle Autocomplete
      if (interaction.isAutocomplete()) {
        if (interaction.commandName === "play") {
          const focusedValue = interaction.options.getFocused();
          if (!focusedValue) return await interaction.respond([]).catch(() => {});

          const node = this.client.shoukaku.getNode();
          if (!node) return await interaction.respond([]).catch(() => {});

          const searchResult = await this.client.utils.resolve(node, focusedValue.startsWith("http") ? focusedValue : `ytsearch:${focusedValue}`).catch(() => null);
          
          if (!searchResult || !searchResult.tracks?.length) {
             return await interaction.respond([]).catch(() => {});
          }

          const choices = searchResult.tracks.slice(0, 10).map((track: any) => ({
            name: `${track.info.title.substring(0, 70)} - ${track.info.author.substring(0, 25)}`,
            value: track.info.uri || track.info.identifier
          }));

          return await interaction.respond(choices).catch(() => {});
        }
      }

      // 2. Handle Slash Commands
      if (interaction.isChatInputCommand()) {
        const cmd: any = this.client.commands.messages.get(interaction.commandName);
        if (!cmd) return;

        let args: string[] = [];
        interaction.options.data.forEach((opt: any) => {
          if (opt.value !== undefined) args.push(String(opt.value));
          if (opt.options) {
             opt.options.forEach((subOpt: any) => {
                if (subOpt.value !== undefined) args.push(String(subOpt.value));
             });
          }
        });

        const dispatcher = this.client.api.get(interaction.guildId);
        
        // Mock a message for compatibility with the legacy command executor
        const fakeMessage = {
          guild: interaction.guild,
          guildId: interaction.guildId,
          channel: interaction.channel,
          author: interaction.user,
          member: interaction.member,
          content: `/${interaction.commandName} ${args.join(" ")}`,
          reply: async (payload: any) => {
            if (interaction.replied || interaction.deferred) return await interaction.followUp(payload);
            return await interaction.reply(payload);
          },
          delete: async () => {}
        };

        return await cmd.exec(fakeMessage, args, "/", dispatcher);
      }

      // 2. Handle Component Interactions (Buttons & Menus)
      if (interaction.isButton() || interaction.isStringSelectMenu()) {
        const customId = interaction.customId;
        const dispatcher = this.client.api.get(interaction.guildId);

        // Security & Premium Checks for interactive components
        if (customId.startsWith("raahi_")) {
          // Vote Check
          const voted = await checkVote(this.client, interaction.user.id);
          if (!voted) {
            return await this.client.utils.safeReply(interaction, {
              content: `💅 **Bestie!** You need to **Vote** to use these premium controls! ✨🌸`,
              components: [this.client.utils.actionRow([
                this.client.utils.button(`link`, `Vote Me`, 5, null, `${this.client.config.voteUrl}`, "⭐")
              ])],
              ephemeral: true,
            });
          }

          // Voice Checks
          const botMember = this.client.utils.getBotMember(interaction.guild);
          if (!interaction.member?.voice?.channel) {
            return await this.client.utils.safeReply(interaction, { content: `🌸 Join a voice channel first queen! ✨`, ephemeral: true });
          }
          if (botMember?.voice?.channelId && interaction.member.voice.channelId !== botMember.voice.channelId) {
            return await this.client.utils.safeReply(interaction, { content: `🌸 We gotta be in the same channel bestie! ✨`, ephemeral: true });
          }

          if (!dispatcher || !dispatcher.player) {
            return await this.client.utils.safeReply(interaction, { content: `🌸 No active vibes right now! Start some music first! ✨`, ephemeral: true });
          }

          // Handle Button Controls
          if (interaction.isButton()) {
            await this.client.utils.safeDeferUpdate(interaction);
            
            switch (customId) {
              case "raahi_pause":
              case "raahi_dj_pause":
                await dispatcher.player.setPaused(!dispatcher.player.paused);
                break;
              case "raahi_skip":
              case "raahi_dj_skip":
                await dispatcher.player.stopTrack();
                break;
              case "raahi_stop":
              case "raahi_dj_stop":
                await dispatcher.destroy();
                break;
              case "raahi_previous":
              case "raahi_dj_previous":
                if (dispatcher.previous) {
                  dispatcher.queue.unshift(dispatcher.previous);
                  await dispatcher.player.stopTrack();
                } else {
                  return await interaction.followUp({ content: "🌸 No previous track in the multiverse! ✨", ephemeral: true });
                }
                break;
              case "raahi_loop":
              case "raahi_dj_loop":
                if (dispatcher.repeat === "off") dispatcher.repeat = "one";
                else if (dispatcher.repeat === "one") dispatcher.repeat = "all";
                else dispatcher.repeat = "off";
                break;
              case "raahi_shuffle":
              case "raahi_dj_shuffle":
                dispatcher.queue = dispatcher.queue.sort(() => Math.random() - 0.5);
                break;
              case "raahi_volLow":
              case "raahi_dj_volLow":
                let volL = (dispatcher.player.volume || 100) - 10;
                await dispatcher.player.setGlobalVolume(Math.max(volL, 10));
                break;
              case "raahi_volHigh":
              case "raahi_dj_volHigh":
                let volH = (dispatcher.player.volume || 100) + 10;
                await dispatcher.player.setGlobalVolume(Math.min(volH, 150));
                break;
              case "raahi_fav":
              case "raahi_dj_fav":
                if (dispatcher.current) {
                  addFavs(interaction.user.id, dispatcher.current);
                  return await interaction.followUp({ content: `💖 Added **${dispatcher.current.info.title.substring(0, 30)}** to your favs! ✨`, ephemeral: true });
                }
                break;
              case "raahi_autoplay":
              case "raahi_dj_autoplay":
                const { getAutoplay, enableAutoplay, disableAutoplay } = await import("../api/db/settings.js");
                const currentAutoplay = getAutoplay(interaction.guildId).SETTING;
                if (currentAutoplay === 1) disableAutoplay(interaction.guildId);
                else enableAutoplay(interaction.guildId);
                dispatcher.aiMode = !dispatcher.aiMode;
                break;
            }

            // Update visuals if DJ setup exists
            if (!dispatcher.stopped) {
              await dispatcher.updateDj(interaction.guild).catch(() => {});
              await dispatcher.updateQueue(interaction.guild, dispatcher.queue).catch(() => {});
            }
          }

          // Handle Select Menu (Filters)
          if (interaction.isStringSelectMenu()) {
            const value = interaction.values[0];
            if (customId === "raahi_filters_menu" || value.startsWith("raahi_filter_") || value.startsWith("raahi_dj_filter_")) {
              let filterName = value.replace("raahi_filter_", "").replace("raahi_dj_filter_", "");
              if (filterName === "reset") filterName = "none";
              
              await dispatcher.setFilter(filterName);
              await this.client.utils.safeDeferUpdate(interaction);
              
              if (customId === "raahi_filters_menu") {
                await interaction.followUp({ content: `🎵 *Slay! Filter set to **${filterName}**! Immaculate vibes!* ✨🌸`, ephemeral: true }).catch(() => {});
              }
            }
          }
        }
      }
    } catch (error: any) {
      if (error?.code === 10062 || error?.code === 40060) return; // Ignore session timeouts
      this.client.logger.error(`[Interaction Error] ${error.message}`);
    }
  };
}
